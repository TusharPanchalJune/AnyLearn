import mongoose from "mongoose";

const commentSchema = new mongoose.Schema({
  user: {},
  Comment: { type: String, required: true },
});

const CommentsSchema = mongoose.model("Comments", commentSchema);
export default CommentsSchema;
