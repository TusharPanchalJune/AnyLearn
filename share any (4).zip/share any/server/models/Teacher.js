import mongoose from "mongoose";

const teacherSchema = new mongoose.Schema({
  userType: { type: String, default: "teacher" },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  course: [],
  ur: { type: String },
  password: { type: String, required: true },
});

teacherSchema.statics.signup = async function (password) {};
const Teacher = mongoose.model("teachers", teacherSchema);

export default Teacher;
