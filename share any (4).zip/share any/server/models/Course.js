import mongoose from "mongoose";

const courseSchema = new mongoose.Schema({
  name: String,
  tutor: String,
  price: String,
  hours: String,
  url: String,
  des: {type:String , default:"Explore our comprehensive courses that offer in-depth, hands-on learning experiences. Our expert-led programs are designed to empower you with practical, industry-focused skills, enhancing your career prospects. Accessible and flexible, our innovative courses cater to diverse learners, fostering lifelong learning."},
  reviews: [
    {
      studentName: {},
      rating: Number,
      reviewText: String,
    },
  ],
  teacher: {
    // Define teacher properties here
  },
  videos: [
    // Define video properties here
  ],
  Quiz1: {
    type: [
      {
        question: String,
        options: [String],
        answer: Number,
      },
    ],
    default: null,
  },
  Quiz2: {
    type: [
      {
        question: String,
        options: [String],
        answer: Number,
      },
    ],
    default: null,
  },
});

const Course = mongoose.model("courses", courseSchema);

export default Course;
