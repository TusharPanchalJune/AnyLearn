import mongoose from "mongoose";

const courseSchema = new mongoose.Schema({
  name: String,
  tutor: String,
  price: "String",
  hours: "String",
  url: "String",
  des: "String",
  reviews: [
    {
      studentName: {},
      rating: Number,
      reviewText: String,
    },
  ],
  teacher: {},
  videos: [],
});

const Course = mongoose.model("Course", courseSchema);

export default Course;
