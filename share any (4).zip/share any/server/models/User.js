import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  userType: { type: String, default: "student" },
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String },
  dob: Date,
  gender: String,
  image: String,
  score: mongoose.Schema.Types.Mixed,
  subscribedTo: [],
});

userSchema.statics.signup = async function (password) {};
const User = mongoose.model("User", userSchema);
export default User;
