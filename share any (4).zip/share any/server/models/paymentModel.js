import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema({
  razorpay_order_id: {
    type: String,
    required: true,
  },
  razorpay_payment_id: {
    type: String,
    required: true,
  },
  razorpay_signature: {
    type: String,
    required: true,
  },
  course: {
    // Add course field
    type: String,
    required: true,
  },
  amount: {
    // Add amount field
    type: Number,
    required: true,
  },
  name: {
    // Add course field
    type: String,
    //required: true,
  },
  email: {
    // Add course field
    type: String,
    //required: true,
  },
});

const Payment = mongoose.model("Payment", paymentSchema);
export default Payment;
