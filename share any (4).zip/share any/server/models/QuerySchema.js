import mongoose from "mongoose";

const querySchema = new mongoose.Schema({
  
  name: String,
  email: String,
  subject: String,
  message: String,
  
});

querySchema.statics.addquery = async function (password) {};

const Query = mongoose.model("Query", querySchema);

export default Query;
