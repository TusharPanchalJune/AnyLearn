import { app } from "./app.js";
import Razorpay from "razorpay";
import { connectDB } from "./config/database.js";
import dotenv from "dotenv";
import User from "./models/User.js";
import bcrypt from "bcrypt";
import session from "express-session";
import MongoDBStoreFactory from "connect-mongodb-session";
import express from "express";
import connect from "connect";
import Teacher from "./models/Teacher.js";
import cors from "cors";
import bodyParser from "body-parser";
import Video from "./models/videoschema.js";
import Course from "./models/Course.js";
import Query from "./models/QuerySchema.js";
import CommentsSchema from "./models/CommentSchema.js";

// const session = require('express-session');
// const MongoDBStore = require('connect-mongodb-session')(session);

const MongoDBStore = MongoDBStoreFactory(session);
const store = new MongoDBStore({
  uri: process.env.MONGO_URI,
  collection: "sessions",
});

app.use(
  session({
    secret: process.env.SECRET_KEY,
    resave: false,
    saveUninitialized: true,
    store: store,
    cookie: {
      maxAge: 3600000, // Session expiration time in milliseconds (1 hour)
    },
  })
);

app.use(
  cors({
    origin: "http://localhost:3000", // Replace with your frontend's domain
    credentials: true,
    optionSuccessStatus: 200,
  })
);
app.use(bodyParser.json());
dotenv.config();
connectDB();

export const instance = new Razorpay({
  key_id: process.env.RAZORPAY_API_KEY,
  key_secret: process.env.RAZORPAY_API_SECRET,
});

app.post("/signup", async (req, res) => {
  const { fullName, email, password, dob, gender, image, agreeTerms } =
    req.body;
  console.log(image);
  console.log(fullName);
  console.log(email);
  console.log(password);
  console.log(dob);
  console.log(agreeTerms);
  console.log(gender);
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);
  console.log(hash);
  const newUser = new User({
    fullName,
    email,
    password: hash,
    dob,
    gender,
    image,

    subscribedTo: [],
  });
  console.log(newUser + "nw u");
  try {
    const savedUser = await newUser.save();
    console.log(savedUser + "sa");
    res.status(201).json(savedUser);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Could not create user" });
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user) {
    var isPasswordMatch = await bcrypt.compare(password, user.password);
    console.log("Password match result:", isPasswordMatch);
  }

  if (!isPasswordMatch) {
    return res.status(401).json({ message: "Wrong password" });
  }
  console.log(user.email);

  if (user) {
    req.session.authenticated = true;
    req.session.user = user;
    //req.session.user.save();
    console.log("Session after login:", req.session.user);
    res.status(200).json(user);
  } else {
    res.status(401).json({ message: "Authentication failed" });
  }
});
app.post("/teacherlogin", async (req, res) => {
  const { email, password } = req.body;
  const user = await Teacher.findOne({ email });
  if (user) {
    var isPasswordMatch = await bcrypt.compare(password, user.password);
    console.log("Password match result:", isPasswordMatch);
  }

  if (!isPasswordMatch) {
    return res.status(401).json({ message: "Wrong password" });
  }
  console.log(user.email);

  if (user) {
    req.session.authenticated = true;
    req.session.user = user;
    //req.session.user.save();
    console.log("Session after login:", req.session.user);
    res.status(200).json(user);
  } else {
    res.status(401).json({ message: "Authentication failed" });
  }
});
const authenticate = (req, res, next) => {
  if (req.session.authenticated) {
    next(); // User is authenticated, continue to the next middleware/route
  } else {
    res.status(401).json({ message: "Unauthorized" });
  }
};

app.get("/getSession", authenticate, (req, res) => {
  //console.log("in getSession: ", req.session);

  const sessionUser = req.session.user;
  // console.log("Session user in /getSession:", sessionUser);
  if (sessionUser) {
    // Session data is available
    console.log("session data sent");
    res.status(200).json(sessionUser);
  } else {
    // No session data found
    res.status(401).json({ message: "No session data" });
  }
});

app.get("/protected", (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  // User is authenticated, fetch data based on req.session.user
  res.json({ user: req.session.user });
});

app.post("/logout", (req, res) => {
  req.session.destroy();
  res.json({ message: "Logged out successfully" });
});

//fetch userlist from DB to admindashboard
app.get("/students", async (req, res) => {
  try {
    const students = await User.find({ userType: "student" }); // Assuming 'userType' is the field that stores the user type
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

//fetch teacherlist from DB to admindashboard
app.get("/teachers", async (req, res) => {
  try {
    const teachers = await Teacher.find(); // Assuming 'userType' is the field that stores the user type
    res.json(teachers);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});
app.post("/postvideo", async (req, res) => {
  const { title, subject, downloadURL, imgurl, courseId, teacherId } = req.body;
  const course = await Course.findById(courseId);
  const newVideo = { title, subject, downloadURL, imgurl };
  course ? course.videos.push(newVideo) : console.log("course not found");
  try {
    console.log(courseId + "courseid");
    const teacher = await Teacher.findById(teacherId);

    if (teacher && newVideo) {
      const courseIndex = teacher.course.findIndex(
        (course) => course._id == courseId
      );
      console.log(courseIndex + "index  ");
      if (courseIndex !== -1) {
        // Push the new video into the course's videos array
        teacher.course[courseIndex].videos.push(newVideo);

        // Save the updated teacher object
        await teacher.save();
        console.log(teacher.course);
        console.log("Video added to the course successfully.");
      } else {
        console.log("Course not found.");
      }

      res.status(201);
    } else {
      console.log("nahi mila");
      console.log(teacher + " teacher");
      console.log(course + " course");
    }
  } catch (error) {
    res.status(500).json({ error: "Error saving video" });
  }
});
app.post("/teacherregister", async (req, res) => {
  const { name, email, password, ur } = req.body;
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);
  try {
    const teacher = new Teacher({
      name,
      email,
      password: hash,
      ur,
      course: [],
    });

    await teacher.save();
    console.log("teacher registered");
    res.status(201).json(teacher);
  } catch (error) {
    console.log(error);
    console.log(error);
    res.status(500).json({ error: "Error saving teacher" });
  }
});
app.get("/getvideos", async (req, res) => {
  try {
    const videos = await Video.find();
    res.status(200).json(videos);
  } catch (error) {
    console.error("Error fetching videos:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.post("/getquestions", async (req, res) => {
  const { courseId, quizn } = req.body;
  console.log(quizn);
  try {
    const course = await Course.findById(courseId);
    if (quizn > 1) {
      res.json(course.Quiz2);
    } else {
      res.json(course.Quiz1);
    }
  } catch (error) {
    console.log(error);
    res.send(error);
  }
});

app.get("/getUser/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;

    const user = await User.findById(userId);
    console.log("user mil g", user);
    res.json(user);
  } catch (error) {
    console.error("Error fetching user data:", error);
    res.status(500).json({ error: "Error fetching user data" });
  }
});

app.post("/updateUserScore", async (req, res) => {
  console.log("updating");
  try {
    const { userId, score } = req.body;

    var user = await User.findById(userId);

    if (!user) {
      console.log("error");
      return res.status(404).json({ error: "User not found" });
    }

    if (!user.hasOwnProperty("score")) {
      user.score = score;
    } else {
      user.score = score + user.score;
    }

    await user.save();
    console.log("updated");
    res.json(user);
  } catch (error) {
    console.error("Error updating user score:", error);
    res.status(500).json({ error: "Error updating user score" });
  }
});

app.post("/getteacher", async (req, res) => {
  try {
    const { teacherId } = req.body;
    console.log(teacherId);
    const teacher = await Teacher.findById(teacherId);
    if (teacher) {
      console.log(teacher);
    }
    res.json(teacher);
  } catch (error) {
    console.log("error he");
    res.status(500).json({ error: "An error occurred" });
  }
});

app.post("/addreview", async (req, res) => {
  const { course, rating, reviewText, userID } = req.body;
  console.log(course);

  try {
    const courses = await Course.findById(course);
    console.log(courses);
    const user = await User.findById(userID);
    if (!courses && !user) {
      return res.status(404).json({ message: "fatal error data not milra" });
    } else {
      // Create a new review object
      const newReview = {
        studentName: user,
        rating: rating,
        reviewText: reviewText,
      };

      courses.reviews.push(newReview);
      console.log("review saved");
      console.log("review saved");
      console.log("review saved");
      console.log("review saved");

      await courses.save();

      return res.status(201).json({ message: "Review added successfully" });
    }
  } catch (error) {
    console.error("Error adding review:", error);
    res.status(500).json({ message: "Server error" });
  }
});

app.post("/getcourses", async (req, res) => {
  console.log("mile ");
  try {
    const courses = await Course.find();

    if (courses.length === 0) {
      return res.status(404).json({ message: "No courses found" });
    }
    console.log("mile");
    return res.json(courses);
  } catch (error) {
    console.error("Error fetching courses:");
    res.status(500).json({ error: "An error occurred" });
  }
});
app.post("/getpurchasedcourses", async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findById(userId);

    if (user.subscribedTo.length === 0) {
      return res.status(404).json({ message: "No courses found" });
    }
    console.log(user.subscribedTo);
    return res.json(user.subscribedTo);
  } catch (error) {
    console.error("Error fetching courses:");
    res.status(500).json({ error: "An error occurred" });
  }
});

app.post("/addquery", async (req, res) => {
  console.log("entered");
  try {
    const { name, email, subject, message } = req.body;

    const newQuery = new Query({
      name: name,
      email: email,
      subject: subject,
      message: message,
    });

    const savedQuery = await newQuery.save();
    console.log(savedQuery);
    res.json(savedQuery);
  } catch (error) {
    res.status(500).json({ error: "An error occurred" });
  }
});

app.post("/getreviews", async (req, res) => {
  try {
    const { courseID } = req.body;
    console.log("course id :", courseID);
    const course = await Course.findById(courseID);
    console.log(course);
    res.json(course);
  } catch (error) {
    res.status(500).json({ error: "An error occurred" });
  }
});

app.post("/uservideos", async (req, res) => {
  try {
    const courseId = req.body.courseId;
    const course = await Course.findById(courseId);
    console.log(course);
    res.json( course );
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
});
app.post("/tee", async (req, res) => {
  const course = await Course.findById("64f1393b5c76e352886a90c9");
  const { quiz1, quiz2 } = req.body;
  console.log(quiz1);
  course.Quiz1 = quiz1;
  course.Quiz2 = quiz2;
  course.save();
  console.log("saved");
  res.send({ messgae: "data updated" });
});
async function addCourse(teacher, name, hours, price, url) {
  const tee = await Teacher.findById(teacher._id);
  const cor = new Course({ name, hours, price, url });
  cor.teacher = tee;
  cor.save();
}
app.post("/addcourse", async (req, res) => {
  const { name, hours, price, userID, url } = req.body;

  try {
    const teacher = await Teacher.findById(userID);

    const course = new Course({ name, hours, price, url });
    teacher.course.push(course);
    teacher.save();
    await addCourse(teacher, name, hours, price, url);
    res.send("DONE").status(200);
  } catch (error) {
    console.error("Error adding course:", error);
    res.status(500).json({ success: false, message: "An error occurred." });
  }
});

app.post("/postdoubt", async (req, res) => {
  console.log("doubt received");
  try {
    const { newComment, user } = req.body;
    console.log(req.body);

    const com = new CommentsSchema({ Comment: newComment, user });
    const saved = await com.save();
    console.log(saved, "saved data");

    res.status(200).json(saved); // Sending a response
  } catch (error) {
    console.error(error);
    res.status(500).send("Error saving comment"); // Sending a response
  }
});
app.get("/getdoubts", async (req, res) => {
  try {
    const array = await CommentsSchema.find();
    res.json(array);
  } catch (error) {
    console.error(error);
    res.status(500).send("Error saving comment"); // Sending a response
  }
});
app.post("/getonevideo", async (req, res) => {
  console.log("video");
  try {
    const { vals, user } = req.body;
    console.log(vals, "");
    console.log(user, "");
    const video = await Course.find();

    if (video) {
      console.log(video);
      res.json(video);
    } else {
      console.log("not found");
      res.send("error");
    }
  } catch (error) {
    console.error(error);
    res.status(500).send("Error saving comment"); // Sending a response
  }
});

app.post("/teacherscourses", async (req, res) => {
  try {
    const { title, subject, downloadURL, imgurl, courseId, teacherId } =
      req.body;

    // Find the teacher by ID
    const teacher = await Teacher.findById(teacherId);
    const newVideo = new Video({ title, subject, downloadURL, imgurl });
    if (!teacher) {
      return res.status(404).json({ error: "Teacher not found" });
    }

    // Find the course to update by its ID in the teacher's course array
    const courseToUpdate = teacher.course.find(
      (course) => course._id.toString() === courseId
    );
    console.log(courseToUpdate, "course to update");
    if (!courseToUpdate) {
      return res
        .status(404)
        .json({ error: "Course not found in teacher's courses" });
    }

    // Find the course in the Course schema based on the provided course ID
    const matchingCourse = await Course.findOne({ name: courseToUpdate.name });
    matchingCourse.videos.push(newVideo);
    console.log("pushed");
    console.log(matchingCourse + "matched");
    matchingCourse.save();

    if (!matchingCourse) {
      res.status(404).json({ error: "Course not found in Courses schema" });
    } else {
      res.send("done");
    }
  } catch (error) {
    console.log(error);
  }
});

app.listen(process.env.PORT, () =>
  console.log(`Server is working on ${process.env.PORT}`)
);
