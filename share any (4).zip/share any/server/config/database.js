import mongoose from "mongoose";
import dotenv from "dotenv";

dotenv.config();

export const connectDB = async () => {
  //const uri = process.env.MONGO_URI;
  const { connection } = await mongoose.connect(
    "mongodb+srv://tusharpanchal016:TusharDB@cluster0.gqmonyh.mongodb.net/?retryWrites=true&w=majority"
  );
  console.log(`MongoDB is connected with ${connection.host}`);
};
