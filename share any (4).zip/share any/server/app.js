import express from "express";
import { config } from "dotenv";
import paymentRoute from "./routes/paymentRoutes.js";
import userRoute from "./routes/userRoutes.js";

import cors from "cors";
import User from "./models/User.js";
import teacherRouter from "./routes/teacherRoutes.js";
import Teacher from "./models/Teacher.js";
import courseRouter from "./routes/courseRoutes.js";

config({ path: "./config/config.env" });

export const app = express();
app.use(
  cors({
    origin: "http://localhost:3000", // Replace with your frontend's domain
    credentials: true,
    optionSuccessStatus: 200,
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", paymentRoute);
//app.use("/register", userController);
app.use("/register", userRoute);

app.get("/api/getkey", (req, res) =>
  res.status(200).json({ key: process.env.RAZORPAY_API_KEY })
);

//fetch studentlist from DB to admindashboard
app.use("/api", userRoute);
app.get("/api/students", async (req, res) => {
  try {
    const students = await User.find({ userType: "student" });
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});
app.use("/api/students", userRoute);

//fetch teacherlist from DB to admindashboard
app.use("/api", teacherRouter);
app.get("/api/teachers", async (req, res) => {
  try {
    const teachers = await Teacher.find();
    res.json(teachers);
  } catch (error) {
    res.status(500).json({ message: "Error fetching teachers", error });
  }
});

app.use("/api", courseRouter);
