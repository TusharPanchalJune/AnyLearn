import express from "express";
import { getTeachers } from "../controllers/teacherController.js";

import Teacher from "../models/Teacher.js";

const teacherRouter = express.Router();

teacherRouter.get("/teachers", getTeachers);
teacherRouter.put("/teachers/:id", async (req, res) => {
  const teacherId = req.params.id;
  const { name, email } = req.body;

  try {
    // Find the teacher by ID and update their information
    const updatedTeacher = await Teacher.findByIdAndUpdate(
      teacherId,
      { name, email },
      { new: true } // This ensures that the updated document is returned
    );

    res.status(200).json(updatedTeacher);
  } catch (error) {
    console.error("Error updating teacher:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

teacherRouter.delete("/teachers/:id", async (req, res) => {
  try {
    const teacherId = req.params.id;

    // Delete the teacher from the database
    await Teacher.findByIdAndDelete(teacherId);

    res.status(204).send(); // No Content
  } catch (error) {
    res.status(500).json({ error: "Error deleting teacher" });
  }
});

teacherRouter.post("/addTeacher", async (req, res) => {
  try {
    const { name, email, course } = req.body;
    const newTeacher = new Teacher({
      userType: "teacher",
      name: name,
      email: email,
      course: course,
    });

    const savedTeacher = await newTeacher.save();
    res.status(201).json(savedTeacher);
  } catch (error) {
    console.error("Error adding student:", error);
    res.status(500).json({ error: "Error adding teacher" });
  }
});
export default teacherRouter;
