import express from "express";
import {
  checkout,
  paymentVerification,
} from "../controllers/paymentController.js";
import Payment from "../models/paymentModel.js";
import User from "../models/User.js";
import Course from "../models/Course.js";

const router = express.Router();

router.route("/checkout").post(checkout);
router.route("/paymentverification").post(paymentVerification);

router.post("/paymentverification", async (req, res) => {
  const course = req.body.course;
  const amount = req.body.amount;
  const name = req.body.name;
  const email = req.body.email;
  const userId = req.body.userId;

  // Create a new payment record
  const payment = new Payment({
    course: courseDetails._id,
    amount: amount,
    name: name,
    email: email,
   
  });

  // Save the payment record
  const savedPayment = await payment.save();

  res.json(savedPayment);
});

export default router;
