import express from "express";
import {
  getCourses,
  addCourse,
  updateCourse,
  deleteCourse,
} from "../controllers/courseController.js";
import Course from "../models/Course.js";

const courseRouter = express.Router();

courseRouter.get("/courses", getCourses);
courseRouter.post("/courses/addCourse", addCourse);
courseRouter.put("/courses/:id", updateCourse);
courseRouter.delete("/courses/:id", deleteCourse);
// courseRouter.put('/courses/:id', async (req, res) => {
//   const courseId = req.params.id;
//   const { name, price, teacher } = req.body;

//   try {
//     // Find the course by ID and update its properties
//     const updatedCourse = await Course.findByIdAndUpdate(
//       courseId,
//       { name, price, teacher },
//       { new: true } // Return the updated course
//     );

//     res.json(updatedCourse);
//   } catch (error) {
//     console.error('Error updating course:', error);
//     res.status(500).json({ message: 'An error occurred while updating the course.' });
//   }
// });
export default courseRouter;
