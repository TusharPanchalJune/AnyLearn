// In paymentRoutes.js or another relevant route file
import express from "express";
import { userControl, getStudents } from "../controllers/userController.js";
import User from "../models/User.js";

const userrouter = express.Router();

userrouter.get("/students", getStudents);
userrouter.route("/register").post(userControl);
// userrouter.post("/register", async (req, res) => {
//   console.log("in userRoute");
//   const fullName = req.body.fullName;
//   const email = req.body.email;
//   const password = req.body.password;
//   const agreeTerms = req.body.agreeTerms;

//   const User = new User({
//     fullName: fullName,
//     email: email,
//     password: password,
//     agreeTerms: agreeTerms,
//   });
//   try {
//     const savedUser = await newUser.save();
//     res.status(201).json(savedUser);
//   } catch (error) {
//     res.status(500).json({ error: "Could not create user" });
//   }
// });

// In your server's userRoutes.js or equivalent file
userrouter.put("/students/:id", async (req, res) => {
  const studentId = req.params.id;
  const { fullName, email } = req.body;

  try {
    // Find the student by ID and update their information
    const updatedStudent = await User.findByIdAndUpdate(
      studentId,
      { fullName, email },
      { new: true } // This ensures that the updated document is returned
    );

    res.status(200).json(updatedStudent);
  } catch (error) {
    console.error("Error updating student:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

userrouter.delete("/students/:id", async (req, res) => {
  try {
    const studentId = req.params.id;
    // Delete the student from the database
    await User.findByIdAndDelete(studentId);

    res.status(204).send(); // No Content
  } catch (error) {
    res.status(500).json({ error: "Error deleting student" });
  }
});

// POST request to add a student
userrouter.post("/addStudent", async (req, res) => {
  try {
    //console.log("Request received:", req.body);
    const { name, email } = req.body;
    const newStudent = new User({
      userType: "student",
      fullName: name,
      email: email,
    });
    //console.log("New student created:", newStudent);
    const savedStudent = await newStudent.save();
    //console.log("Student saved:", savedStudent);
    res.status(201).json(savedStudent);
  } catch (error) {
    console.error("Error adding student:", error);
    res.status(500).json({ error: "Error adding student" });
  }
});
export default userrouter;
