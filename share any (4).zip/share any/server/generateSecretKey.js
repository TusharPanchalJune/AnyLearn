import crypto from "crypto";

// Generate a random byte buffer of 32 bytes
const secretKeyBuffer = crypto.randomBytes(32);

// Convert the byte buffer to a hexadecimal string
const secretKey = secretKeyBuffer.toString("hex");

// Log the generated secret key to the console
console.log("Secret Key:", secretKey);
