// Import required modules and setup
import { app } from "./app.js";
import dotenv from "dotenv";
import { connectDB } from "./config/database.js";

// Load environment variables from .env file
dotenv.config();

// Establish database connection
connectDB();

// Define the port for the server to listen on
const PORT = process.env.PORT || 3000; // Default to 3000 if PORT is not defined in .env

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
