import { instance } from "../server.js";
import crypto from "crypto";
import Payment from "../models/paymentModel.js";
import User from "../models/User.js";
import Course from "../models/CourseSchema.js";
export const checkout = async (req, res) => {
  //payment details
  //const { course, amount } = req.body;

  const options = {
    amount: Number(req.body.amount * 100), // amount in the smallest currency unit
    currency: "INR",
  };

  const order = await instance.orders.create(options);

  res.status(200).json({
    success: true,
    order,
  });
};

export const paymentVerification = async (req, res) => {
  console.log(req.body); // Check the received data
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
    req.body;

  const {
    course, // Make sure these fields are coming from the frontend
    amount,
    name,
    email,
    userId,

    // Make sure these fields are coming from the frontend
  } = req.query;
  console.log(req.query);

  try {
    // Find the course details using the course name
    const courseDetails = await Course.findOne({ name: course });

    if (!courseDetails) {
      return res.status(400).json({ error: "Course not found" });
    }

    const user = await User.findOneAndUpdate(
      { _id: userId },
      { $push: { subscribedTo: courseDetails } },
      { new: true } // To return the updated user document
    );

    if (!user) {
      return res.status(400).json({ error: "User not found" });
    }
  } catch (error) {
    console.log(error);
  }

  const body = razorpay_order_id + "|" + razorpay_payment_id;

  const expectedSignature = crypto
    .createHmac("sha256", process.env.RAZORPAY_API_SECRET)
    .update(body.toString())
    .digest("hex");

  const isAuthentic = expectedSignature === razorpay_signature;

  if (isAuthentic) {
    await Payment.create({
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      course,
      amount,
      name,
      email,
    });
    

    // res.redirect(
    //   `http://localhost:3000/paymentsuccess?reference=${razorpay_payment_id}&coursename=${course}`
    // );
  } else {
    res.status(400).json({
      success: false,
    });
  }
};
