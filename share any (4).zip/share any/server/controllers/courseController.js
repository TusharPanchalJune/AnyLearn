import Course from "../models/Course.js";
import Teacher from "../models/Teacher.js";

export const getCourses = async (req, res) => {
  try {
    const courses = await Course.find().populate("teacher"); // Populate teacher information
    res.json(courses);
  } catch (error) {
    res.status(500).json({ message: "Error fetching courses", error });
  }
};

export const addCourse = async (req, res) => {
  try {
    const { name, price, teacher } = req.body;
    const newCourse = new Course({
      title: name,
      price,
      teacher,
    });

    const savedCourse = await newCourse.save();
    res.status(201).json(savedCourse);
  } catch (error) {
    console.error("Error adding course:", error);
    res.status(500).json({ error: "Error adding course" });
  }
};

export const updateCourse = async (req, res) => {
  try {
    const courseId = req.params.id;
    console.log(`Received PUT request for course ID: ${courseId}`);
    const { name, price, teacher } = req.body;
    console.log(teacher);
    const newTeacher = await Teacher.findById(teacher);
    console.log(newTeacher);
    const updatedCourse = await Course.findById(courseId);

    updatedCourse.name = name;
    updatedCourse.price = price;
    updatedCourse.teacher = newTeacher;
    updatedCourse.save();

    //console.log("Course updated successfully:", updatedCourse);
    res.status(200).json(updatedCourse);
  } catch (error) {
    console.error("Error updating course:", error);
    res.status(500).json({ error: "Error updating course" });
  }
};

export const deleteCourse = async (req, res) => {
  try {
    const courseId = req.params.id;
    await Course.findByIdAndDelete(courseId);

    res.status(204).send();
  } catch (error) {
    console.error("Error deleting course:", error);
    res.status(500).json({ error: "Error deleting course" });
  }
};
