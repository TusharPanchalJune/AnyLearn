import bcrypt from "bcrypt";
import User from "../models/User.js";

// Handle user registration
export const userControl = async (req, res) => {
  app.post("/register", async (req, res) => {
    console.log("in usercontroller");
    const { fullName, email, password, dob, gender, image, agreeTerms } =
      req.body;
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    const newUser = new User({
      fullName,
      email,
      password: hash, // Remember to hash the password before saving it
      dob,
      gender,
      image,
      agreeTerms,
    });
    try {
      const savedUser = await newUser.save();
      res.status(201).json(savedUser);
    } catch (error) {
      res.status(500).json({ error: "Could not create user" });
    }
  });
};
export const getStudents = async (req, res) => {
  try {
    const students = await User.find({ userType: "student" });
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};
