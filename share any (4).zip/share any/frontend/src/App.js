import React, { useEffect, useState } from "react";
import "./App.css";
import "./pages/style.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NewNavbar from "./pages/NewNavbar";
import AdminNavbar from "./pages/Admin/AdminNavbar";
import TeacherNavbar from "./pages/Teacher/TeacherNavbar";
import Home from "./pages/Home";
import About from "./pages/About";
import Courses from "./pages/Courses";
import Coursesvid from "./pages/Coursesvid";
import Educators from "./pages/TeacherSection";
import Testimonial from "./pages/Testimonial";
import Contact from "./pages/Contact";
import Footer from "./pages/Footer";
import Register from "./pages/Student/Register";
import Login from "./pages/Login";
import StudentDashboard from "./pages/Student/StudentDashboard";
import ReviewForm from "./pages/ReviewForm";
import QuizApp from "./pages/QuizApp";
import AdminDashboard from "./pages/Admin/AdminDashboard";
import TeacherRegistration from "./pages/Teacher/TeacherRegistration";
import TeacherProfile from "./pages/TeacherProfile";
import TeacherSection from "./pages/TeacherSection";
import TeacherDashboard from "./pages/Teacher/TeacherDashboard";
import PaymentSuccess from "./pages/paymentSuccessful";
import TeacherUpload from "./pages/TeacherUpload";
import Quiz from "./pages/Quiz";
import PurchasedCourses from "./pages/PurchasedCourses";
import UploadVideo from "./pages/UploadVideo";
import VidUpload from "./pages/VidUpload";
import Video from "./pages/Video";
import WatchVideo from "./pages/WatchVideo";
import StudentLoginNav from "./pages/StudentLoginNav";
import { fetchSessionData } from "./pages/Student/FetchData";
import axios from "axios";
import AddCourse from "./pages/AddCourse";

function StudentProtectedRoute({ children, userData }) {
  if (userData && userData.userType == "student") {
    return children;
  }
  return (
    <div style={{ marginTop: "80px", height: "80vh" }}>
      <h1>Kindly Login First</h1>
    </div>
  );
}
function AdminProtectedRoute({ children, userData }) {
  if (userData && userData.userType == "admin") {
    return children;
  }
  return (
    <div style={{ marginTop: "80px", height: "80vh" }}>
      <h1>Kindly Login First</h1>
    </div>
  );
}
function TeacherProtectedRoute({ children, userData }) {
  if (userData && userData.userType == "teacher") {
    return children;
  }
  return (
    <div style={{ marginTop: "80px", height: "80vh" }}>
      <h1>Kindly Login First</h1>
    </div>
  );
}

const App = () => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userData, setUserData] = useState(null);
  const [change, setChange] = useState(false);
  const [url, setUrl] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      const res = await axios.post(
        "http://localhost:4000/login",
        {
          email: email,
          password: password,
        },
        { withCredentials: true }
      );
      setUserData(res.data);
      if (userData.userType == "Admin") {
        //await fetchAdminData(); //har role k liye karna padega
      }
    };
    if (change) {
      fetchData();
      setChange(false);
    }
  }, [change]);
  // useEffect(() => {
  //   const fetchData = async () => {
  //     const res = await axios.post(
  //       "http://localhost:4000/login",
  //       {
  //         email: email,
  //         password: password,
  //       },
  //       { withCredentials: true }
  //     );
  //     setUserData(res.data);
  //     if (userData.userType == "Admin") {
  //       //await fetchAdminData(); //har role k liye karna padega
  //     }
  //   };
  //   fetchData();
  // }, []);

  return (
    <div className="App">
      {userData ? (
        userData.userType == "teacher" ? (
          <TeacherNavbar setUserData={setUserData} /> //not logged in
        ) : userData.userType == "student" ? (
          <StudentLoginNav setUserData={setUserData} />
        ) : (
          <AdminNavbar setUserData={setUserData} />
        )
      ) : (
        <NewNavbar setUserData={setUserData} />
      )}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Login" element={<Login setUserData={setUserData} />} />
        <Route
          path="/register"
          element={<Register setEmail={setEmail} setPassword={setPassword} />}
        />
        <Route
          path="/contact"
          element={
            <StudentProtectedRoute
              children={<Contact />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/testimonial"
          element={
            <StudentProtectedRoute
              children={<Testimonial />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/register"
          element={
            <StudentProtectedRoute
              children={<Register />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/about"
          element={
            <StudentProtectedRoute
              children={<About />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/courses"
          element={
            <StudentProtectedRoute
              children={<Courses />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/reviewform"
          element={
            <StudentProtectedRoute
              children={<ReviewForm />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/quizapp"
          element={
            <StudentProtectedRoute
              children={<Quiz />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/paymentsuccess"
          element={
            <StudentProtectedRoute
              children={<PaymentSuccess />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/purchased"
          element={
            <StudentProtectedRoute
              children={<PurchasedCourses />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/purchased/video"
          element={
            <StudentProtectedRoute
              children={<Video setUrl={setUrl} />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/watchvideo"
          element={
            <StudentProtectedRoute
              children={<WatchVideo setUrl={setUrl} url={url} />}
              userData={userData}
            ></StudentProtectedRoute>
          }
        />
        <Route
          path="/teacherUpload"
          element={
            <TeacherProtectedRoute
              children={<TeacherUpload />}
              userData={userData}
            ></TeacherProtectedRoute>
          }
        />
        <Route
          path="/admindashboard"
          element={
            <AdminProtectedRoute
              children={<AdminDashboard />}
              userData={userData}
            ></AdminProtectedRoute>
          }
        />
        <Route
          path="/teacherprofile"
          element={
            <TeacherProtectedRoute
              children={<TeacherProfile />}
              userData={userData}
            ></TeacherProtectedRoute>
          }
        />

        <Route
          path="/uploadvideo"
          element={
            <TeacherProtectedRoute
              children={<UploadVideo />}
              userData={userData}
            ></TeacherProtectedRoute>
          }
        />
        <Route
          path="/addcourse"
          element={
            <TeacherProtectedRoute
              children={<AddCourse />}
              userData={userData}
            ></TeacherProtectedRoute>
          }
        />
        <Route
          path="/vidupload"
          element={
            <TeacherProtectedRoute
              children={<VidUpload />}
              userData={userData}
            ></TeacherProtectedRoute>
          }
        />
        <Route
          path="/teacherregister"
          element={<TeacherRegistration userData={userData} />}
        />

        {/* <Route
          path="/orders.html"
          element={
            <ProtectedRoute
              children={<Orders userData={userData} />}
              userData={userData}
            ></ProtectedRoute>
          }
        /> */}
        <Route
          path="*"
          element={
            <h1 style={{ marginTop: "80px", height: "50vh" }}>No Such Page</h1>
          }
        />
      </Routes>
      <Footer></Footer>
    </div>
  );
};

export default App;
