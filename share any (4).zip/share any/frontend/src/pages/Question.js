import React from "react";
import './quiz.css';

const Question = ({ question, onOptionClick }) => {
  return (
    <div>
      <p>{question.question}</p>
      <div>
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => onOptionClick(option)}
            disabled={question.selectedOption !== null}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Question;
