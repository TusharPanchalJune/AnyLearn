import React from 'react';
import './courses.css'; // Import your CSS file here

const TeachersSection = () => {
  // Define teacher data (you can fetch this from an API or use state)
  const teachers = [
    {
      name: 'Tushar Panchal',
      role: 'developer',
      playlists: 4,
      videos: 18,
      likes: 1208,
    },
    {
      name: 'Mrunali Salunke',
      role: 'developer',
      playlists: 4,
      videos: 18,
      likes: 1208,
    },
    {
      name: 'Mayur Bhole',
      role: 'developer',
      playlists: 4,
      videos: 18,
      likes: 1208,
    },
    {
      name: 'Shubham Shelar',
      role: 'developer',
      playlists: 4,
      videos: 18,
      likes: 1208,
    },
    {
      name: 'Divyam Sahu',
      role: 'developer',
      playlists: 4,
      videos: 18,
      likes: 1208,
    },
    
    // Add more teachers here
  ];

  return (
    <section className="teachers">
      <h1 className="heading">Expert Teachers</h1>
      <form action="" method="post" className="search-tutor">
        <input
          type="text"
          name="search_box"
          placeHolder="search tutors..."
          required
          maxLength="100"
        />
        <button type="submit" className="fas fa-search" name="search_tutor"></button>
      </form>
      <div className="box-container">
        {/* Teacher Box 1 */}
        <div className="box offer">
          <h3>become a tutor</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, itaque ipsam fuga ex et aliquam.</p>
          <a to="/teacherregister" className="inline-btn">get started</a>
        </div>

        {/* Teacher Boxes (You can map through your data to generate these) */}
        {teachers.map((teacher, index) => (
          <div className="box" key={index}>
            <div className="tutor">
              <img src={`images/pic-${index + 2}.jpg`} alt="" />
              <div>
                <h3>{teacher.name}</h3>
                <span>{teacher.role}</span>
              </div>
            </div>
            <p>total playlists : <span>{teacher.playlists}</span></p>
            <p>total videos : <span>{teacher.videos}</span></p>
            <p>total likes : <span>{teacher.likes}</span></p>
            <a to="./teacherprofile" className="inline-btn">view profile</a>
          </div>
        ))}
      </div>
    </section>
  );
};

export default TeachersSection;
