import React, { useState, useEffect } from "react";
import Category from "./Category";
import axios from "axios";
import "./style.css";
import { fetchSessionData } from "./Student/FetchData";

const Courses = () => {
  const [sessionData, setSessionData] = useState(null);
  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
      console.log(data);
    });
  }, []);
  const [courses, setCourses] = useState([]);
  const renderRatingStars = (count) => {
    const stars = [];

    for (let i = 0; i < count; i++) {
      stars.push(<i key={i} className="fas fa-star stars  "></i>);
    }

    return stars;
  };
  const handleClick = (course) => {
    if (
      sessionData.subscribedTo.some(
        (subscribedCourse) => subscribedCourse._id.toString() == course._id
      )
    ) {
      return true;
    } else {
      return false;
    }
  };
  const checkoutHandler = async (course, amount, name, email) => {
    const userId = sessionData._id;
    console.log("checkouthandler called");
    alert("checkouthandler called");
    const payload = {
      course,
      amount,
      name,
      email,
      userId,
    };

    try {
      const response = await axios.post(
        "http://localhost:4000/api/checkout",
        payload,
        { withCredentials: true }
      );
      console.log(response.data); // Handle the response from the backend

      const {
        data: { key },
      } = await axios.get("http://localhost:4000/api/getkey");

      const options = {
        key,
        amount: response.data.order.amount,
        currency: "INR",
        name: "AnyLearn",
        description: "Tutorial for RazorPay",
        image: "https://example.com/your_logo", // Add the logo
        order_id: response.data.order.id,
        callback_url: `http://localhost:4000/api/paymentverification?course=${course}&amount=${amount}&name=${name}&email=${email}&userId=${userId}`,
        prefill: {
          name: sessionData.fullName,
          email: sessionData.email,
        },
        notes: {
          address: "Razorpay Corporate Office",
          course,
          name,
          email,
          userId,
        },
        theme: {
          color: "#3399cc",
        },
      };
      const razor = new window.Razorpay(options);
      razor.open();
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getcourses();
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.onload = () => {
      console.log("Razorpay script loaded");
    };
    document.body.appendChild(script);
  }, []);

  async function getcourses() {
    try {
      console.log("method called");
      const response = await axios.post("http://localhost:4000/getcourses");
      const data = response.data;

      setCourses(data);
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  }

  return (
    <div className="container-xxl py-5">
      <div className="container">
        <Category />
        <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
          <h1 className="mb-5">Popular Courses</h1>
        </div>
        <div className="row g-4 justify-content-center">
          {courses.map((course, index) => (
            <div
              key={course._id}
              className="col-lg-4 col-md-6 wow fadeInUp"
              data-wow-delay="0.1s"
            >
              <div className="course-item bg-light">
                <div className="position-relative overflow-hidden">
                  <img
                    className="img-fluid"
                    src={course.url}
                    alt={course.title}
                  />
                  <div className="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                    <a
                      to={`./courses/${course._id}`}
                      className="flex-shrink-0 btn btn-sm btn-primary px-3 border-end"
                      style={{ borderRadius: "30px 0 0 30px" }}
                    >
                      Read More
                    </a>
                    <a
                      onClick={() =>
                        handleClick(course)
                          ? alert("alredy")
                          : checkoutHandler(
                              course.name,
                              course.price,
                              sessionData.fullName,
                              sessionData.email
                            )
                      }
                      className="flex-shrink-0 btn btn-sm btn-primary px-3"
                      style={{ borderRadius: "0 30px 30px 0" }}
                    >
                      Join Now
                    </a>
                  </div>
                </div>
                <div className="text-center p-4 pb-0">
                  <h3 className="mb-0">{course.name}</h3>
                  <div className="mb-3">
                    <div className="stars">
                      {renderRatingStars(parseInt(course.reviews.rating))}
                    </div>
                  </div>
                  <h5 className="mb-4">₹{course.price}</h5>
                </div>
                <div className="d-flex border-top">
                  <small className="flex-fill text-center border-end py-2">
                    <i className="fa fa-user-tie text-primary me-2"></i>
                    {course.teacher.name}
                  </small>
                  <small className="flex-fill text-center border-end py-2">
                    <i className="fa fa-clock text-primary me-2"></i>
                    {course.hours}
                  </small>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Courses;
