import "./login.css";
import React, { useEffect, useState, useTransition } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

function Login({ setUserData }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [userType, setUserType] = useState(""); // Added userType state
  const [url, setUrl] = useState(""); // Added userType state
  var API_URL = "";

  useEffect(() => {
    if (userType === "teacher") {
      setUrl("/teacherregister");
    } else {
      setUrl("/register");
    }
  }, [userType]);
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate inputs
    if (email === "" || password === "" || userType === "") {
      alert("Please fill in all fields.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailRegex.test(email)) {
    } else {
      const phoneRegex = /^\d{10}$/;
      if (isNaN(email) || !phoneRegex.test(email)) {
        alert("Please enter a valid email address or a 10-digit phone number.");
        return;
      }
    }

    if (userType == "teacher") {
      API_URL = "http://localhost:4000/teacherlogin";
      setUrl("/teacherregister");
    } else {
      API_URL = "http://localhost:4000/login";
      setUrl("/register");
    }
    //console.log("before axios.post");
    try {
      const response = await axios.post(
        API_URL,
        {
          email,
          password,
        },
        {
          withCredentials: true,
        }
      );
      //console.log("after axios.post");
      if (response.ok) {
        setUserData(response.data);
        alert("Invalid credentials. Please try again later.");
        return;
      }

      const data = response.data;
      setUserData(data);
      const userRole = data.userType;
      setUserType(userRole); // Set the user's role in state
      setEmail("");
      setPassword("");
      if (userRole === "admin") {
        navigate("/admindashboard");
      } else if (userRole === "teacher") {
        console.log("in Teacher");
        navigate("/teacherprofile");
      } else if (userRole === "student") {
        navigate("/");
      }
    } catch (error) {
      console.error("An error occurred:", error);
      alert("An error occurred. Please try again later.");
    }
  };

  return (
    <div className="container2">
      <form className="login-form2" onSubmit={handleSubmit}>
        {/* Rest of your form components */}
        <img src="./images/logo1.jpg" alt="Company Logo" />
        <h1>Welcome to AnyLearn</h1>
        <select
          value={userType}
          onChange={(e) => setUserType(e.target.value)}
          required
        >
          <option value="">Select role</option>
          <option value="student">Student</option>
          <option value="teacher">Teacher</option>
        </select>

        <input
          type="text"
          id="email"
          placeholder="Registered Email or Phone"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          id="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {/* Rest of your form components */}
        <button type="submit">Log In</button>
        {/* Rest of your form components */}
        <div className="register-link mt-2 reg">
          New User? <Link to={url}>Register</Link>
        </div>
      </form>
    </div>
  );
}

export default Login;
