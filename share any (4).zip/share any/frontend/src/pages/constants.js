module.exports = {
  ROLES: {
    ADMIN: "admin",
    TEACHER: "teacher",
    STUDENT: "student",
  },
};
