import React from 'react';
import './courses.css'; 

const Coursesvid = () => {
  
  const courses = [
    {
      tutor: 'Tushar Panchal',
      date: '30-08-2023',
      thumbSrc: './images/thumb-9.png',
      videoCount: '10 videos',
      title: 'Complete React tutorial',
    },
    {
      tutor: 'Mrunali Salunke',
      date: '30-08-2023',
      thumbSrc: './images/thumb-8.png',
      videoCount: '10 videos',
      title: 'Complete MySQL tutorial',
    },
    {
      tutor: 'Mayur Bhole',
      date: '30-08-2023',
      thumbSrc: './images/thumb-3.png',
      videoCount: '10 videos',
      title: 'Complete JS tutorial',
    },
    {
      tutor: 'Shubham Shelar',
      date: '30-08-2023',
      thumbSrc: './images/thumb-1.png',
      videoCount: '10 videos',
      title: 'Complete HTML tutorial',
    },
    {
      tutor: 'Gaurav Parit',
      date: '30-08-2023',
      thumbSrc: './images/thumb-5.png',
      videoCount: '10 videos',
      title: 'Complete JQuery tutorial',
    },
    {
      tutor: 'Divyam Sahu',
      date: '30-08-2023',
      thumbSrc: './images/thumb-6.png',
      videoCount: '10 videos',
      title: 'Complete SASS tutorial',
    },
    
    
    // Add more courses here
  ];

  return (
    <section className="courses">
      <div className="box-container">
        {courses.map((course, index) => (
          <div className="box" key={index}>
            <div className="tutor">
              <img src={`images/pic-${index + 2}.jpg`} alt="" />
              <div className="info">
                <h3>{course.tutor}</h3>
                <span>{course.date}</span>
              </div>
            </div>
            <div className="thumb">
              <img src={course.thumbSrc} alt="" />
              <span>{course.videoCount}</span>
            </div>
            <h3 className="title">{course.title}</h3>
            <a to="playlist.html" className="inline-btn">
              view playlist
            </a>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Coursesvid;
