import React, { useState, useEffect } from "react";
import { Table, Button, Modal, Form } from "react-bootstrap";
import axios from "axios";

const AdminDashboard = () => {
  const [students, setStudents] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [newStudent, setNewStudent] = useState({ name: "", email: "" });
  const [editStudent, setEditStudent] = useState(null);
  const [editedStudentName, setEditedStudentName] = useState("");
  const [editedStudentEmail, setEditedStudentEmail] = useState("");
  const [showTeacherModal, setShowTeacherModal] = useState(false);
  const [showAddTeacherModal, setShowAddTeacherModal] = useState(false);
  const [newTeacher, setNewTeacher] = useState({
    name: "",
    email: "",
    course: "",
  });
  const [editTeacher, setEditTeacher] = useState(null);
  const [editedTeacherName, setEditedTeacherName] = useState("");
  const [editedTeacherEmail, setEditedTeacherEmail] = useState("");
  const [editedTeacherCourse, setEditedTeacherCourse] = useState("");
  const [showAddCourseModal, setShowAddCourseModal] = useState(false);
  const [newCourse, setNewCourse] = useState({
    name: "",
    price: "",
    teacherId: "",
  });
  const [editCourse, setEditCourse] = useState(null);
  const [editedCourseName, setEditedCourseName] = useState("");
  const [editedCoursePrice, setEditedCoursePrice] = useState("");
  const [editedCourseTeacherId, setEditedCourseTeacherId] = useState("");

  const [purchasedCourses, setPurchasedCourses] = useState([]);

  useEffect(() => {
    // Fetch students and teachers data here and update state
    axios
      .get("http://localhost:4000/api/students")
      .then((response) => {
        console.log(response.data);
        setStudents(response.data);
      })
      .catch((error) => {
        console.error("Error fetching student users:", error);
      });
    axios
      .get("http://localhost:4000/api/teachers")
      .then((response) => {
        console.log(response.data);
        setTeachers(response.data);
      })
      .catch((error) => {
        console.error("Error fetching teacher data:", error);
      });

    axios
      .get("http://localhost:4000/api/courses")
      .then((response) => {
        console.log(response.data);
        setCourses(response.data);
      })
      .catch((error) => {
        console.error("Error fetching course data:", error);
      });
    // For example:
    // fetchStudents().then(data => setStudents(data));
    // fetchTeachers().then(data => setTeachers(data));
    // fetchCourses().then(data => setCourses(data));
    // fetchPurchasedCourses().then(data => setPurchasedCourses(data));
  }, []);

  const handleAddStudent = () => {
    axios
      .post("http://localhost:4000/api/students/addStudent", newStudent) // Updated URL
      .then((response) => {
        setStudents([...students, response.data]);
        setNewStudent({ fullName: "", email: "" });
        setShowAddStudentModal(false);
        alert("Student added successfully");
      })
      .catch((error) => {
        console.error("Error adding student:", error);
        alert("Error adding student");
      });
  };

  const handleDeleteStudent = (studentId) => {
    // Make an API call to delete the student
    axios
      .delete(`http://localhost:4000/api/students/${studentId}`)
      .then(() => {
        // Remove the deleted student from the students list in the state
        const updatedStudents = students.filter(
          (student) => student._id !== studentId
        );
        setStudents(updatedStudents);
        // Show a success alert
        alert("Student deleted successfully");
      })
      .catch((error) => {
        console.error("Error deleting student:", error);
      });
  };

  const handleAddTeacher = () => {
    axios
      .post("http://localhost:4000/api/addTeacher", newTeacher)
      .then((response) => {
        setTeachers([...teachers, response.data]);
        setNewTeacher({ name: "", email: "", course: "" });
        setShowAddTeacherModal(false);
        alert("Teacher added successfully");
      })
      .catch((error) => {
        console.error("Error adding teacher:", error);
        alert("Error adding teacher");
      });
  };

  const handleDeleteTeacher = (teacherId) => {
    // Make an API call to delete the teacher
    axios
      .delete(`http://localhost:4000/api/teachers/${teacherId}`)
      .then(() => {
        // Remove the deleted teacher from the teachers list in the state
        const updatedTeachers = teachers.filter(
          (teacher) => teacher._id !== teacherId
        );
        setTeachers(updatedTeachers);
        // Show a success alert
        alert("Teacher deleted successfully");
      })
      .catch((error) => {
        console.error("Error deleting teacher:", error);
      });
  };

  const handleAddCourse = () => {
    axios
      .post("http://localhost:4000/api/addCourse", newCourse) // Update the URL
      .then((response) => {
        setCourses([...courses, response.data]);
        setNewCourse({ name: "", price: "", teacherId: "" });
        setShowAddCourseModal(false);
        alert("Course added successfully");
      })
      .catch((error) => {
        console.error("Error adding course:", error);
        alert("Error adding course");
      });
  };

  const handleDeleteCourse = (courseId) => {
    axios
      .delete(`http://localhost:4000/api/courses/${courseId}`)
      .then(() => {
        const updatedCourses = courses.filter(
          (course) => course._id !== courseId
        );
        setCourses(updatedCourses);
        alert("Course deleted successfully");
      })
      .catch((error) => {
        console.error("Error deleting course:", error);
      });
  };

  return (
    <>
      <div>
        <div className="d-flex justify-content-end mt-2">
          <Button>Admin Logout</Button>
        </div>
        <div className="d-flex justify-content-center my-3">
          <h1>Admin Dashboard</h1>
        </div>
        <div className="mx-5">
          {/* Display Students */}
          <div className="my-4">
            <h2>Students List</h2>
            <Table striped bordered>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  {/* Other columns */}
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student._id}>
                    <td>{student._id}</td>
                    <td>
                      {editStudent && editStudent._id === student._id ? (
                        <input
                          type="text"
                          value={editedStudentName}
                          onChange={(e) => setEditedStudentName(e.target.value)}
                        />
                      ) : (
                        student.fullName
                      )}
                    </td>
                    <td>
                      {editStudent && editStudent._id === student._id ? (
                        <input
                          type="email"
                          value={editedStudentEmail}
                          onChange={(e) =>
                            setEditedStudentEmail(e.target.value)
                          }
                        />
                      ) : (
                        student.email
                      )}
                    </td>
                    {/* Other cells */}
                    <td>
                      {editStudent && editStudent._id === student._id ? (
                        <Button
                          variant="primary"
                          onClick={() => {
                            // Make an API call to update the student's information
                            axios
                              .put(
                                `http://localhost:4000/api/students/${editStudent._id}`,
                                {
                                  fullName: editedStudentName,
                                  email: editedStudentEmail,
                                }
                              )
                              .then((response) => {
                                // Update the students list in the state with the updated information
                                const updatedStudents = students.map((s) =>
                                  s._id === editStudent._id ? response.data : s
                                );
                                setStudents(updatedStudents);
  
                                // Clear the edit state
                                setEditStudent(null);
                                setEditedStudentName("");
                                setEditedStudentEmail("");
                              })
                              .catch((error) => {
                                console.error("Error updating student:", error);
                              });
                          }}
                        >
                          Save
                        </Button>
                      ) : (
                        <>
                          <Button
                            variant="success m-2"
                            onClick={() => {
                              setEditStudent(student);
                              setEditedStudentName(student.fullName);
                              setEditedStudentEmail(student.email);
                            }}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="danger m-2"
                            onClick={() => handleDeleteStudent(student._id)}
                          >
                            Delete
                          </Button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
  
            {/* Add Student Button */}
            <Button onClick={() => setShowAddStudentModal(true)}>
              Add Student
            </Button>
  
            {/* Add Student Modal */}
            <Modal
              show={showAddStudentModal}
              onHide={() => setShowAddStudentModal(false)}
            >
              <Modal.Header closeButton>
                <Modal.Title>Add Student</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  <Form.Group>
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter name"
                      value={newStudent.name}
                      onChange={(e) =>
                        setNewStudent({ ...newStudent, name: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group>
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                      type="email"
                      placeholder="Enter email"
                      value={newStudent.email}
                      onChange={(e) =>
                        setNewStudent({ ...newStudent, email: e.target.value })
                      }
                    />
                  </Form.Group>
                </Form>
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant="secondary"
                  onClick={() => setShowAddStudentModal(false)}
                >
                  Close
                </Button>
                <Button variant="primary" onClick={handleAddStudent}>
                  Add Student
                </Button>
              </Modal.Footer>
            </Modal>
          </div>
  
          {/* Display Teachers */}
          <div className="my-4">
            <h2>Teachers List</h2>
            <Table striped bordered>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Course</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {teachers.map((teacher) => (
                  <tr key={teacher._id}>
                    <td>{teacher._id}</td>
                    <td>
                      {editTeacher && editTeacher._id === teacher._id ? (
                        <input
                          type="text"
                          value={editedTeacherName}
                          onChange={(e) => setEditedTeacherName(e.target.value)}
                        />
                      ) : (
                        teacher.name
                      )}
                    </td>
  
                    <td>
                      {editTeacher && editTeacher._id === teacher._id ? (
                        <input
                          type="email"
                          value={editedTeacherEmail}
                          onChange={(e) =>
                            setEditedTeacherEmail(e.target.value)
                          }
                        />
                      ) : (
                        teacher.email
                      )}
                    </td>
                    <td>{teacher.course}</td>
                    <td>
                      {editTeacher && editTeacher._id === teacher._id ? (
                        <Button
                          variant="primary"
                          onClick={() => {
                            // Make an API call to update the Teacher's information
                            axios
                              .put(
                                `http://localhost:4000/api/teachers/${editTeacher._id}`,
                                {
                                  name: editedTeacherName,
                                  email: editedTeacherEmail,
                                }
                              )
                              .then((response) => {
                                // Update the Teacher list in the state with the updated information
                                const updatedTeachers = teachers.map((t) =>
                                  t._id === editTeacher._id ? response.data : t
                                );
                                setTeachers(updatedTeachers);
  
                                // Clear the edit state
                                setEditTeacher(null);
                                setEditedTeacherName("");
                                setEditedTeacherEmail("");
                              })
                              .catch((error) => {
                                console.error("Error updating teacher:", error);
                              });
                          }}
                        >
                          Save
                        </Button>
                      ) : (
                        <>
                          <Button
                            variant="success m-2"
                            onClick={() => {
                              setEditTeacher(teacher);
                              setEditedTeacherName(teacher.name);
                              setEditedTeacherEmail(teacher.email);
                            }}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="danger m-2"
                            onClick={() => handleDeleteTeacher(teacher._id)}
                          >
                            Delete
                          </Button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
  
            {/* Add Teacher Button */}
            <Button onClick={() => setShowTeacherModal(true)}>
              Add Teacher
            </Button>
  
            {/* Add Teacher Modal */}
            <Modal
              show={showTeacherModal}
              onHide={() => setShowTeacherModal(false)}
            >
              <Modal.Header closeButton>
                <Modal.Title>Add Teacher</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  <Form.Group>
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter name"
                      value={newTeacher.name}
                      onChange={(e) =>
                        setNewTeacher({ ...newTeacher, name: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group>
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                      type="email"
                      placeholder="Enter email"
                      value={newTeacher.email}
                      onChange={(e) =>
                        setNewTeacher({ ...newTeacher, email: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group>
                    <Form.Label>Course</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter course"
                      value={newTeacher.course}
                      onChange={(e) =>
                        setNewTeacher({ ...newTeacher, course: e.target.value })
                      }
                    />
                  </Form.Group>
                </Form>
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant="secondary"
                  onClick={() => setShowTeacherModal(false)}
                >
                  Close
                </Button>
                <Button variant="primary" onClick={handleAddTeacher}>
                  Add Teacher
                </Button>
              </Modal.Footer>
            </Modal>
          </div>
  
          {/* Display Courses */}
          <div className="my-4">
  <h2>Courses List</h2>
  <Table striped bordered>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Price</th>
        <th>Teacher</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {courses.map((course) => (
        <tr key={course._id}>
          <td>{course._id}</td>
          <td>
            {editCourse && editCourse._id === course._id ? (
              <input
                type="text"
                value={editedCourseName}
                onChange={(e) => setEditedCourseName(e.target.value)}
              />
            ) : (
              course.name
            )}
          </td>
          <td>
            {editCourse && editCourse._id === course._id ? (
              <input
                type="number"
                value={editedCoursePrice}
                onChange={(e) => setEditedCoursePrice(e.target.value)}
              />
            ) : (
              course.price
            )}
          </td>
          <td>
            {editCourse && editCourse._id === course._id ? (
              <select
                value={editedCourseTeacherId}
                onChange={(e) => setEditedCourseTeacherId(e.target.value)}
              >
                <option value="">Select a teacher</option>
                {teachers.map((teacher) => (
                  <option key={teacher._id} value={teacher._id}>
                    {teacher.name}
                  </option>
                ))}
              </select>
            ) : (
              course.teacher && course.teacher.name
            )}
          </td>
          <td>
            {editCourse && editCourse._id === course._id ? (
              <Button
                variant="primary"
                onClick={() => {
                  console.log(editedCourseTeacherId);
                  axios
                    .put(
                      `http://localhost:4000/api/courses/${editCourse._id}`,
                      {
                        name: editedCourseName,
                        price: editedCoursePrice,
                        teacher: editedCourseTeacherId,
                      }
                    )
                    .then((response) => {
                      const updatedCourses = courses.map((c) =>
                        c._id === editCourse._id ? response.data : c
                      );
                      setCourses(updatedCourses);

                      setEditCourse(null);
                      setEditedCourseName("");
                      setEditedCoursePrice("");
                      setEditedCourseTeacherId("");
                    })
                    .catch((error) => {
                      console.error("Error updating course:", error);
                    });
                }}
              >
                Save
              </Button>
            ) : (
              <>
                <Button
                  variant="success m-2"
                  onClick={() => {
                    setEditCourse(course);
                    setEditedCourseName(course.name);
                    setEditedCoursePrice(course.price);
                    setEditedCourseTeacherId(course.teacher?._id);
                  }}
                >
                  Edit
                </Button>
                <Button
                  variant="danger m-2"
                  onClick={() => handleDeleteCourse(course._id)}
                >
                  Delete
                </Button>
              </>
            )}
          </td>
        </tr>
      ))}
    </tbody>
  </Table>

  
            {/* Add Course Button */}
            <Button onClick={() => setShowAddCourseModal(true)}>
              Add Course
            </Button>
  
            {/* Add Course Modal */}
            <Modal
              show={showAddCourseModal}
              onHide={() => setShowAddCourseModal(false)}
            >
              <Modal.Header closeButton>
                <Modal.Title>Add Course</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  <Form.Group>
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter course name"
                      value={newCourse.name}
                      onChange={(e) =>
                        setNewCourse({ ...newCourse, name: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group>
                    <Form.Label>Price</Form.Label>
                    <Form.Control
                      type="number"
                      placeholder="Enter course price"
                      value={newCourse.price}
                      onChange={(e) =>
                        setNewCourse({ ...newCourse, price: e.target.value })
                      }
                    />
                  </Form.Group>
                  <Form.Group>
                    <Form.Label>Teacher</Form.Label>
                    <Form.Control
                      as="select"
                      value={newCourse.teacherId}
                      onChange={(e) =>
                        setNewCourse({
                          ...newCourse,
                          teacherId: e.target.value,
                        })
                      }
                    >
                      <option value="">Select a teacher</option>
                      {teachers.map((teacher) => (
                        <option key={teacher._id} value={teacher._id}>
                          {teacher.name}
                        </option>
                      ))}
                    </Form.Control>
                  </Form.Group>
                </Form>
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant="secondary"
                  onClick={() => setShowAddCourseModal(false)}
                >
                  Close
                </Button>
                <Button variant="primary" onClick={handleAddCourse}>
                  Add Course
                </Button>
              </Modal.Footer>
            </Modal>
          </div>
  
          <div className="my-4">
            {/* Display Purchased Courses */}
            <h2>Purchased Courses List</h2>
            <Table striped bordered>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Course</th>
                  <th>Student</th>
                  <th>Teacher</th>
                  <th>Date of Purchase</th>
                </tr>
              </thead>
              <tbody>
                {purchasedCourses.map((purchasedCourse) => (
                  <tr key={purchasedCourse.id}>
                    <td>{purchasedCourse.id}</td>
                    <td>{purchasedCourse.courseName}</td>
                    <td>{purchasedCourse.studentName}</td>
                    <td>{purchasedCourse.teacherName}</td>
                    <td>{purchasedCourse.purchaseDate}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </>
  );
  
};

export default AdminDashboard;
