import React, { useEffect } from "react";
import Comments from "./Comments";
import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
function WatchVideo({ setUrl, url }) {
  const [videoId, setVideoId] = useState("");
  const [video, setVideo] = useState(null);

  return (
    <section className="watch-video">
      <div className="video-container">
        <div className="video">
          <video controls width="100%" controlsList="nodownload">
            <source src={url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
        <h3 className="title">{}</h3>

        <p className="description">
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Itaque
          labore ratione, hic exercitationem mollitia obcaecati culpa dolor
          placeat provident porro. Lorem, ipsum dolor sit amet consectetur
          adipisicing elit. Aliquid iure autem non fugit sint. A, sequi rerum
          architecto dolor fugiat illo, iure velit nihil laboriosam cupiditate
          voluptatum facere cumque nemo!
        </p>
      </div>
      <Comments />
    </section>
  );
}

export default WatchVideo;
