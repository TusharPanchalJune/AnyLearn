import React, { useState, useEffect } from "react";
import axios from "axios";
import "./courses.css";
import { useLocation } from "react-router-dom";

const Review = (props) => {
  const renderRatingStars = (count) => {
    const stars = [];

    for (let i = 0; i < count; i++) {
      stars.push(<i key={i} className="fas fa-star stars"></i>);
    }

    return stars;
  };

  return (
    <div className="box">
      <p>{props.reviewText}</p>
      <div className="student">
        <img src={props.imageUrl} alt={"abcd"} />
        <div>
          <h3>{props.studentName}</h3>
          <div className="stars">
            {renderRatingStars(parseInt(props.rating))}
          </div>
        </div>
      </div>
    </div>
  );
};
// ... (imports and other code)

const Reviews = () => {
  const [reviewsArray, setReviewsArray] = useState([]);
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const courseId = queryParams.get("courseId");

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const response = await axios.post("http://localhost:4000/getreviews", {
        courseID: courseId,
      });
      // Assuming the response.data is an array or an object containing the "reviews" array
      // If it's an object containing "reviews" array, extract it
      if (Array.isArray(response.data)) {
        setReviewsArray(response.data);
      } else if (response.data && Array.isArray(response.data.reviews)) {
        setReviewsArray(response.data.reviews);
      }
    } catch (error) {
      console.error("Error fetching reviews:", error);
    }
  };

  return (
    <section className="reviews">
      <h1 className="heading">Student's Reviews</h1>
      <div className="box-container">
        {reviewsArray.map((review, index) => (
          <Review
            key={index}
            reviewText={review.reviewText}
            imageUrl={review.studentName.image}
            studentName={review.studentName.fullName}
            rating={review.rating}
          />
        ))}
      </div>
    </section>
  );
};

export default Reviews;
