import React from 'react';
import './style.css';

const VidUpload = () => {
  return (
    
    <section className="playlist-details">
      <h1 className="heading">Playlist Details</h1>
      <div className="row">
        <div className="column">
          <form action="" method="post" className="save-playlist">
    
          </form>
          <div className="thumb">
            <img src="images/pic" alt="" />
            <span>10 videos</span>
          </div>
        </div>
        <div className="column">
          <div className="tutor">
            <img src="images/pic-2.jpg" alt="" />
            <div>
              <h3>Tushar Panchal</h3>
              <span>21-10-2022</span>
            </div>
          </div>
          <div className="details">
            <h3>complete HTML tutorial</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum minus reiciendis, error sunt veritatis exercitationem deserunt velit doloribus itaque voluptate.</p>
            <a to="/uploadvideo" className="inline-btn">Upload Video</a>
          </div>
        </div>
      </div>
    </section>
  );
};
export default VidUpload;