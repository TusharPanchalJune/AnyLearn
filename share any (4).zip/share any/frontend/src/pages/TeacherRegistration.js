import React, { useState } from "react";
import "./TeacherRegister.css";
import axios from "axios";
import { storage } from "./config/firebase";
import { uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { ref as sRef } from "firebase/storage";
import { Link } from "react-router-dom";

function TeacherRegistration() {
  const [downloadURL, setDownloadURL] = useState("");
  const [videoFile, setVideoFile] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [coverLetter, setCoverLetter] = useState("");
  const [errors, setErrors] = useState({});

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setVideoFile(selectedFile);
  };

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const validateEmail = (email) => {
    const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    return emailRegex.test(email);
  };

  const validatePassword = (password) => {
    // Add your password validation logic here
    return password.length >= 6; // Password should be at least 6 characters
  };

  const handleUpload = async () => {
    // Validate email and password
    const newErrors = {};

    if (!name) {
      newErrors.name = "Name is required";
    }

    if (!email) {
      newErrors.email = "Email is required";
    } else if (!validateEmail(email)) {
      newErrors.email = "Invalid email address";
    }

    if (!password) {
      newErrors.password = "Password is required";
    } else if (!validatePassword(password)) {
      newErrors.password = "Password should be at least 6 characters";
    }

    if (!videoFile) {
      newErrors.videoFile = "Video file is required";
    }

    if (!coverLetter) {
      newErrors.coverLetter = "Cover Letter is required";
    }

    setErrors(newErrors);

    // If there are validation errors, stop the submission
    if (Object.keys(newErrors).length > 0) {
      return;
    }

    // Continue with the file upload and registration
    const fileRef = sRef(storage, `teacher/${videoFile.name}`);
    const uploadTask = uploadBytesResumable(fileRef, videoFile);

    // Handle file upload and registration as before
    // ...
  };

  return (
    <div className="teacherregister-container">
      <h4 className="mb-4">Teacher Registration</h4>

      <div className="row g-3">
        <div className="col-12 col-sm-6">
          <input
            type="text"
            name="name"
            className="form-control3"
            placeholder="Your Name"
            value={name}
            onChange={handleNameChange}
            required
          />
          {errors.name && <p className="error-text">{errors.name}</p>}
        </div>
        <div className="col-12 col-sm-6">
          <input
            type="email"
            name="email"
            className="form-control3"
            placeholder="Your Email"
            value={email}
            onChange={handleEmailChange}
            required
          />
          {errors.email && <p className="error-text">{errors.email}</p>}
        </div>
        <div className="col-12 col-sm-6">
          <input
            type="password"
            name="password"
            className="form-control3"
            placeholder="Your Password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
          {errors.password && <p className="error-text">{errors.password}</p>}
        </div>
        <div className="col-12 col-sm-6">
          <input
            type="file"
            name="portfolio"
            className="form-control3"
            placeholder=" Website"
            onChange={handleFileChange}
          />
          {errors.videoFile && <p className="error-text">{errors.videoFile}</p>}
        </div>
        <div className="col-12">
          <textarea
            name="coverLetter"
            className="form-control3"
            rows="5"
            placeholder="Cover Letter"
            value={coverLetter}
            onChange={(e) => setCoverLetter(e.target.value)}
            required
          />
          {errors.coverLetter && (
            <p className="error-text">{errors.coverLetter}</p>
          )}
        </div>
        <div className="col-12">
          <button
            onClick={handleUpload}
            className="btn btn-primary3 w-100"
            type="submit"
          >
            Submit
          </button>
        </div>
      </div>
      <div className="register-link mt-2 reg">
        Already Registerd? <Link to="/login">Login</Link>
      </div>
    </div>
  );
}

export default TeacherRegistration;
