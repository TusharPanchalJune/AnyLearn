// import React, { useState, useEffect } from "react";
// import "./style.css";
// import VidUpload from "./VidUpload";
// import axios from "axios";
// import { useLocation, useNavigate } from "react-router-dom";

// const TeacherDashboard = () => {
//   const [videos, setVideos] = useState([]);
//   const navigate = useNavigate();
//   const location = useLocation();
//   const queryParams = new URLSearchParams(location.search);

//   useEffect(() => {
//     fetchVideos();
//   }, []);

//   const fetchVideos = async () => {
//     try {
//       const response = await axios.post("http://localhost:4000/teachervideos", {

//       });
//       console.log(response.data);
//       setVideos(response.data);
//     } catch (error) {
//       console.error("Error fetching videos:", error);
//     }
//   };

//   return (
//     <section className="playlist-videos">
//       <VidUpload />
//       <h1 className="heading">Playlist Videos</h1>
//       <div className="box-container">
//         {videos.map((video) => (
//           <a
//             className="box"
//             href={`watch-video/${video.downloadURL}`}
//             key={video.id}
//           >
//             <i className="fas fa-play"></i>
//             <img src={video.imgurl} alt={video.title} />
//             <h3>{video.title}</h3>
//             <h3>{video.subject}</h3>
//           </a>
//         ))}
//       </div>
//     </section>
//   );
// };

// export default TeacherDashboard;
import React from "react";

const TeacherDashboard = () => {
  return <div>TeacherDashboard</div>;
};

export default TeacherDashboard;
