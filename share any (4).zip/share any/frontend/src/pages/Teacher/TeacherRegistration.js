import React, { useState } from "react";
import "./TeacherRegister.css";
import axios from "axios";
import { storage } from "../config/firebase.js";
import { uploadBytesResumable, getDownloadURL } from "firebase/storage";

import { ref as sRef } from "firebase/storage";

function TeacherRegistration() {
  const [downloadURL, setDownloadURL] = useState("");
  const [videoFile, setvideoFile] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const handleFileChange = (event) => {
    console.log("file change event");
    const selectedFile = event.target.files[0];
    setvideoFile(selectedFile);
  };

  const handleNameChange = (event) => {
    setName(event.target.value);
  };
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handleUpload = async () => {
    console.log(name, email);
    if (!videoFile) {
      console.log("hello");
    }
    if (!videoFile || !name || !email) {
      console.error("Please fill in all fields.");
      return;
    }

    const fileRef = sRef(storage, `teacher/${videoFile.name}`);
    const uploadTask = uploadBytesResumable(fileRef, videoFile);
    console.log("upload k pehle");

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        let progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log(`Upload progress: ${progress}%`);
        console.log("balle balle");
      },
      (error) => {
        console.error("Error uploading file:", error);
      },
      async () => {
        console.log("Upload completed");
        var ur;
        try {
          ur = await getDownloadURL(fileRef);

          setDownloadURL(ur);
          console.log(downloadURL + "downloadURL");
          console.log(ur + "  url");
        } catch (error) {
          console.error("Error:", error);
        }
        setDownloadURL(ur);
        try {
          console.log(password + "executed");
          const response = await axios.post(
            "http://localhost:4000/teacherregister",
            {
              name,
              email,
              password,
              ur,
            }
          );
          console.log("Teacher data saved:", response.data);
          setDownloadURL("");
        } catch (error) {
          console.error("Error saving Teacher  data:", error);
        }
      }
    );
  };

  return (
    <div className="teacherregister-container">
      <h4 className="mb-4">Teacher Registration</h4>

      <div className="row g-3">
        <div className="col-12 col-sm-6">
          <input
            type="text"
            name="name"
            className="form-control3"
            placeholder="Your Name"
            //value={formData.name}
            onChange={handleNameChange}
            required
          />
        </div>
        <div className="col-12 col-sm-6">
          <input
            type="email"
            name="email"
            className="form-control3"
            placeholder="Your Email"
            //value={formData.email}
            onChange={handleEmailChange}
            required
          />
        </div>
        <div className="col-12 col-sm-6">
          <input
            type="password"
            name="password"
            className="form-control3"
            placeholder="Your Password"
            //value={formData.email}
            onChange={handlePasswordChange}
            required
          />
        </div>
        <div className="col-12 col-sm-6">
          <input
            type="file"
            name="portfolio"
            className="form-control3"
            placeholder=" Website"
            // value={formData.portfolio}
            onChange={handleFileChange}
          />
        </div>
        <div className="col-12">
          <textarea
            name="coverLetter"
            className="form-control3"
            rows="5"
            placeholder="Coverletter"
            //value={formData.coverLetter}
            //onChange={handleInputChange}
            required
          />
        </div>
        <div className="col-12">
          <button
            onClick={handleUpload}
            className="btn btn-primary3 w-100"
            type="submit"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}

export default TeacherRegistration;
