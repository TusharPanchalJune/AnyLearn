import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";
import { getFirestore } from "@firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDRbMsb4y1KHBsiJqJ13zjxd7TiJNlQQ8Y",
  authDomain: "anylearn-365b5.firebaseapp.com",
  projectId: "anylearn-365b5",
  storageBucket: "anylearn-365b5.appspot.com",
  messagingSenderId: "909125864683",
  appId: "1:909125864683:web:650911d7a199177a1f42ae",
};

const app = initializeApp(firebaseConfig);

export const storage = getStorage(app);
export const db = getFirestore(app);
