import React, { useState, useEffect } from "react";
import "./TeacherRegister.css";
import axios from "axios";
import { storage } from "./config/firebase";
import { uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { ref as sRef } from "firebase/storage";
import { fetchSessionData } from "./Student/FetchData";

function AddCourse() {
  const [image, setImage] = useState(null);
  const [title, setTitle] = useState("");
  const [hours, setHours] = useState("");
  const [price, setPrice] = useState("");
  const [sessionData, setSessionData] = useState(null);
  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
    });
  }, []);
  const handleHoursChange = (e) => {
    setHours(e.target.value);
  };
  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };
  const handlePriceChange = (e) => {
    setPrice(e.target.value);
  };
  const handleChange = (e) => {
    setTitle(e.target.value);
  };

  const [isSuccess, setIsSuccess] = useState(false); // Added state for success message

  const handleUpload = async () => {
    if (!image) {
      alert("no image sent");
    }
    if (!image || !hours || !title || !price) {
      alert("Please fill in all fields.");
      return;
    }

    const fileRef = sRef(storage, `course/${image.name}`);
    const uploadTask = uploadBytesResumable(fileRef, image);
    uploadTask.on(
      "state_changed",
      (snapshot) => {
        let progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log(`Upload progress: ${progress}%`);
      },
      (error) => {
        console.error("Error uploading file:", error);
      },
      async () => {
        console.log("Upload completed");
        var url;
        try {
          url = await getDownloadURL(fileRef);

          console.log(url + "  url");
        } catch (error) {
          console.error("Error:", error);
        }

        try {
          const response = await axios.post("http://localhost:4000/addcourse", {
            name:title,
            hours,
            price,
            userID: sessionData._id,
            url,
          });
          console.log("Teacher data saved:", response.data);
          setIsSuccess(true);
        } catch (error) {
          console.error("Error saving Teacher  data:", error);
        }
      }
    );
  };

  return (
    <div className="add-course-container">
      <h1>Add Course</h1>
      {isSuccess ? (
        <div className="success-message">Course added successfully!</div>
      ) : (
        <>
          <div>
            <label htmlFor="title">Course Title:</label>
            <input
              type="text"
              id="title"
              name="title"
              value={title}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label htmlFor="price">Course Price:</label>
            <input
              type="number"
              id="price"
              name="price"
              value={price}
              onChange={handlePriceChange}
              required
            />
          </div>
          <div>
            <label htmlFor="courseHours">Course Hours:</label>
            <input
              type="text"
              id="courseHours"
              name="courseHours"
              value={hours}
              onChange={handleHoursChange}
              required
            />
          </div>
          <div>
            <label htmlFor="courseImage">Course Image:</label>
            <input
              type="file"
              id="courseImage"
              name="courseImage"
              accept="image/*"
              onChange={handleImageChange}
              required
            />
          </div>
          <div>
            <button onClick={handleUpload} type="submit">
              Add Course
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default AddCourse;
