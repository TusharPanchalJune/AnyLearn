import React, { useState, useEffect } from "react";
import "./review.css";
import { fetchSessionData } from "./Student/FetchData";
import { useLocation, useNavigate } from "react-router-dom";

const ReviewForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const courseId = queryParams.get("courseId");
  console.log(courseId + "id aya");
  const [studentName, setStudentName] = useState("");
  const [course, setCourse] = useState("");
  const [rating, setRating] = useState("");
  const [reviewText, setReviewText] = useState("");

  const [submitted, setSubmitted] = useState(false);
  const [sessionData, setSessionData] = useState(null);

  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);

      console.log("session ka ", sessionData);
    });
  }, []);
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(reviewText);

    try {
      const response = await fetch("http://localhost:4000/addreview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userID: sessionData._id,
          rating,
          reviewText,
          course: courseId,
        }),
      });

      if (response.ok) {
        setSubmitted(true);
        navigate(`/testimonial?submitted=true&courseId=${courseId}`);
      } else {
        console.error("Failed to submit review");
      }
    } catch (error) {
      console.error("An error occurred:", error);
    }
  };
  return (
    <div className="container1">
      <h1>Student Review Entry</h1>
      {submitted ? (
        <div className="container1" id="confirmation1">
          <h2>Thank you htmlFor your review!</h2>
          <p>Your feedback is important to us.</p>
        </div>
      ) : (
        <>
          <label htmlFor="studentName">Name:</label>
          <input
            type="text"
            id="studentName"
            name="studentName"
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)}
            required
          />

          <label htmlFor="course">Course:</label>
          <input
            type="text"
            id="course"
            name="course"
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            required
          />

          <label htmlFor="rating">Rating:</label>
          <div className="star-rating">
            {[5, 4, 3, 2, 1].map((value) => (
              <React.Fragment key={value}>
                <input
                  type="radio"
                  id={`star${value}`}
                  // Use checked={rating === value} to set the selected radio button
                  checked={rating === value.toString()}
                  value={value} // Use value={value}
                  onChange={(e) => setRating(e.target.value)}
                />
                <label htmlFor={`star${value}`}></label>
              </React.Fragment>
            ))}
          </div>

          <label htmlFor="review">Review:</label>
          <textarea
            id="review"
            name="review"
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            rows="4"
            required
          ></textarea>

          <button onClick={handleSubmit} type="submit">
            Submit
          </button>
        </>
      )}
    </div>
  );
};

export default ReviewForm;
