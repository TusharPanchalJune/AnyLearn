import React, { useState } from "react";
import { storage, db } from "./firebase"; // Make sure to update the path to your Firebase initialization file
import { uploadBytesResumable, getDownloadURL } from "firebase/storage";

import { ref as sRef } from "firebase/storage";
import axios from "axios";

var VideoUploadForm = () => {
  const [downloadURL, setDownloadURL] = useState("");
  const [videoFile, setVideoFile] = useState(null);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");

  const handleFileChange = (event) => {
    console.log("file change event");
    const selectedFile = event.target.files[0];
    setVideoFile(selectedFile);
  };

  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };

  const handleSubjectChange = (event) => {
    setSubject(event.target.value);
  };

  const handleUpload = async () => {
    if (!videoFile || !title || !subject) {
      console.error("Please fill in all fields.");
      return;
    }

    const fileRef = sRef(storage, `videos/${videoFile.name}`);
    const uploadTask = uploadBytesResumable(fileRef, videoFile);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        let progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log(`Upload progress: ${progress}%`);
      },
      (error) => {
        console.error("Error uploading file:", error);
      },
      async () => {
        console.log("Upload completed");
        var url;
        try {
          url = await getDownloadURL(fileRef);

          setDownloadURL(url);
          console.log(downloadURL + "downloadURL");
          console.log(url + "  url");
        } catch (error) {
          console.error("Error:", error);
        }
        setDownloadURL(url);
        try {
          const response = await axios.post("http://localhost:4000/postvideo", {
            title,
            subject,
            url,
          });
          console.log("Video data saved:", response.data);
          setDownloadURL("");
        } catch (error) {
          console.error("Error saving video data:", error);
        }
      }
    );
  };

  return (
    <div>
      <h2>Upload Video to Firebase Storage</h2>
      <input type="file" accept="video/*" onChange={handleFileChange} />
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={handleTitleChange}
      />
      <input
        type="text"
        placeholder="Subject"
        value={subject}
        onChange={handleSubjectChange}
      />
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default VideoUploadForm;
