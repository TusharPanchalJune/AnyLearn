import React from "react";
import "./style.css";

const CourseDets = ({ course }) => {
  if (!course) {
    return null; // Return null if the course data is not available yet
  }

  return (
    <section className="playlist-details">
      <h1 className="heading">Playlist Details</h1>
      <div className="row">
        <div className="column">
          <form action="" method="post" className="save-playlist"></form>
          <div className="thumb">
            {/* Check if 'videos' property exists before accessing 'length' */}
            <img src={course.url} alt="" />
            <span>{course.videos && course.videos.length} videos</span>
          </div>
        </div>
        <div className="column">
          <div className="tutor">
            {/* Check if 'teacher' property exists before accessing 'name' */}
            <img src={course.teacher.ur} alt="" />
            <div>
              <h3>{course.teacher && course.teacher.name}</h3>
            </div>
          </div>
          <div className="details">
            {/* Check if 'name' and 'des' properties exist before accessing them */}
            <h3>{course.name}</h3>
            <p>{course.des}</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CourseDets;
