import React, { useState, useEffect } from "react";
import Category from "./Category";
import axios from "axios";
import "./style.css";
import { fetchSessionData } from "./Student/FetchData";
import { Link } from "react-router-dom";

const PurchasedCourses = () => {
  const [courses, setCourses] = useState([]);
  const [sessionData, setSessionData] = useState(null);
  const renderRatingStars = (count) => {
    const stars = [];

    for (let i = 0; i < count; i++) {
      stars.push(<i key={i} className="fas fa-star stars  "></i>);
    }

    return stars;
  };

  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
      console.log(data);
      console.log("session set");
    });
  }, []);

  useEffect(() => {
    if (sessionData) {
      getcourses();
    }
  });

  async function getcourses() {
    try {
      const response = await axios.post(
        "http://localhost:4000/getpurchasedcourses",
        { userId: sessionData._id }
      );
      const data = response.data;

      setCourses(data);
    } catch (error) {
      console.error("Error fetching courses:", error);
    }
  }

  return (
    <div className="container-xxl py-5">
      <div className="container">
        <Category />
        <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
          <h1 className="mb-5">Your Courses</h1>
        </div>
        <div className="row g-4 justify-content-center">
          {courses.map((course, index) => (
            <div
              key={course._id}
              className="col-lg-4 col-md-6 wow fadeInUp"
              data-wow-delay="0.1s"
            >
              <div className="course-item bg-light">
                <div className="position-relative overflow-hidden">
                  <img
                    className="img-fluid"
                    src={course.url}
                    alt={course.title}
                  />
                  <div className="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                    <Link
                      to={`./video?courseId=${course._id}`}
                      className="flex-shrink-0 btn btn-sm btn-primary px-3 border-end"
                      style={{ borderRadius: "30px 0 0 30px" }}
                    >
                      View
                    </Link>
                    <Link
                      to={`/reviewform?courseId=${course._id}`}
                      className="flex-shrink-0 btn btn-sm btn-primary px-3"
                      style={{ borderRadius: "0 30px 30px 0" }}
                    >
                      Post Review
                    </Link>
                  </div>
                </div>
                <div className="text-center p-4 pb-0">
                  <h3 className="mb-0">{course.price}</h3>
                  <div className="mb-3">
                    <div className="stars">
                      {renderRatingStars(parseInt(course.reviews.rating))}
                    </div>
                  </div>
                  <h5 className="mb-4">{course.name}</h5>
                </div>
                <div className="d-flex border-top">
                  <small className="flex-fill text-center border-end py-2">
                    <i className="fa fa-user-tie text-primary me-2"></i>
                    {course.teacher.name}
                  </small>
                  <small className="flex-fill text-center border-end py-2">
                    <i className="fa fa-clock text-primary me-2"></i>
                    {course.hours}
                  </small>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PurchasedCourses;
