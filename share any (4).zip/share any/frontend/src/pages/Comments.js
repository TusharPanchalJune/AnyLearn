import React, { useState, useEffect } from "react";
import axios from "axios";
import { fetchSessionData } from "./Student/FetchData";

function Comments() {
  const [comments, setComments] = useState([]); // State to store comments
  const [newComment, setNewComment] = useState(""); // State for the new comment input
  const [sessionData, setSessionData] = useState(null);

  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
    });
    fetchComments(); // Fetch comments on component mount
  }, []);

  const handleCommentChange = (e) => {
    setNewComment(e.target.value);
  };

  const fetchComments = async () => {
    try {
      const response = await axios.get("http://localhost:4000/getdoubts");
      setComments(response.data);
      console.log(response.data); // Set the comments array
    } catch (error) {
      console.log(error);
    }
  };

  const handleAddComment = async (e) => {
    e.preventDefault();
    if (newComment.trim() !== "") {
      try {
        const response = await axios.post("http://localhost:4000/postdoubt", {
          newComment,
          user: sessionData,
        });

        fetchComments();

        // Clear the input field
        setNewComment("");
      } catch (error) {
        console.log(error);
      }
    }
  };

  return (
    <section className="comments">
      <form className="add-comment">
        <h3>Post Doubt</h3>
        <textarea
          name="comment_box"
          placeholder="Enter your comment"
          value={newComment}
          onChange={handleCommentChange}
          required
          maxLength="1000"
          cols="30"
          rows="10"
        ></textarea>
        <button
          type="submit"
          value="Add Comment"
          className="inline-btn"
          name="add_comment"
          onClick={handleAddComment}
        >
          Add Comment
        </button>
      </form>
      <h1 className="heading">Doubts</h1>
      <div className="box-container border">
        {comments.map((comment, index) => (
          <div key={index} className="box" style={{ float: "left" }}>
            <p>{comment.user.fullName}</p>
            <div className="comment-box">
              <p>{comment.Comment}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Comments;
