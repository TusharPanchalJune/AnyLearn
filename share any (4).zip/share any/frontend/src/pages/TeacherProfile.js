import React, { useState, useEffect } from "react";
import "./courses.css";
import Coursesvid from "./Coursesvid";
import axios from "axios";
import { Link } from "react-router-dom";
import { fetchSessionData } from "./Student/FetchData";

const TeacherProfile = () => {
  const [teacherData, setTeacherData] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [showAddVideoModal, setShowAddVideoModal] = useState(false);
  const [sessionData, setSessionData] = useState(null);

  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
      console.log(data);
      console.log("session set");
    });
  }, []);

  // const fetchTeacherData = async () => {
  //   try {
  //     const response = await axios.post(
  //       `http://localhost:4000/getteacher`,
  //       {
  //         teacherId: sessionData._id,
  //       },
  //       {
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //       }
  //     );

  //     if (response.status === 200) {
  //       const data = response.data; // Access data directly from response
  //       setTeacherData(data);
  //     } else {
  //       console.error("Error fetching teacher data:", response.status);
  //     }
  //   } catch (error) {
  //     console.error("Error fetching teacher data:", error);
  //   }
  // };
  function handleClick(course) {
    setSelectedCourse(course);
  }
  console.log(teacherData, "Teacher Dta");
  return (
    <section className="teacher-profile">
      <h1 className="heading">Profile Details</h1>
      <div className="details">
        {sessionData ? (
          <div className="tutor">
            <img src={sessionData?.ur} alt={sessionData?.name} />
            <h3>{sessionData?.name}</h3>
            <span>{sessionData?.role}</span>
          </div>
        ) : (
          <p>Loading teacher's data...</p>
        )}
      </div>
      {/* Display list of courses */}
      {sessionData && sessionData?.course.length > 0 && (
        <div className="courses-list">
          <h2>Your Courses</h2>
          <table className="courses-table">
            <thead>
              <tr>
                <th>Course Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {sessionData?.course.map((course) => (
                <tr key={course._id}>
                  <td>{course.name}</td>
                  <td>
                    <Link
                      to={`/uploadvideo?&courseId=${course._id}`}
                      onClick={() => handleClick(course._id)}
                    >
                      Add Video
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
};

export default TeacherProfile;
