import React, { Component } from "react";
import Question from "./Question";
import './quiz.css';

class QuizApp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      questions: [
        {
          id: 1,
          question: "What is 2 + 2?",
          options: ["3", "4", "5", "6"],
          correctAnswer: "4",
          selectedOption: null,
        },
        {
          id: 2,
          question: "What is the smallest header in HTML by default?",
          options: ["h1", "h2", "h6", "h4"],
          correctAnswer: "h6",
          selectedOption: null,
        },
        {
          id: 3,
          question: "We enclose HTML tags within?",
          options: ["{ }", "< >", "!!", "none"],
          correctAnswer: "< >",
          selectedOption: null,
        },
      ],
      currentQuestionIndex: 0,
      score: 0,
      quizCompleted: false,
    };
  }

  handleOptionClick = (selectedOption) => {
    const { currentQuestionIndex, questions } = this.state;
    const currentQuestion = questions[currentQuestionIndex];

    if (currentQuestion.selectedOption === null) {
      currentQuestion.selectedOption = selectedOption;
      this.setState({ questions });

      if (selectedOption === currentQuestion.correctAnswer) {
        this.setState((prevState) => ({ score: prevState.score + 1 }));
      }
    }
  };

  handleNextQuestion = () => {
    const { currentQuestionIndex, questions } = this.state;
    if (currentQuestionIndex + 1 < questions.length) {
      this.setState((prevState) => ({
        currentQuestionIndex: prevState.currentQuestionIndex + 1,
      }));
    } else {
      this.setState({ quizCompleted: true });
    }
  };

  handlePreviousQuestion = () => {
    const { currentQuestionIndex } = this.state;
    if (currentQuestionIndex > 0) {
      this.setState((prevState) => ({
        currentQuestionIndex: prevState.currentQuestionIndex - 1,
      }));
    }
  };

  render() {
    const { questions, currentQuestionIndex, score, quizCompleted } = this.state;
    const currentQuestion = questions[currentQuestionIndex];

    return (
      <div className="quiz-container">
        <h1>Quiz Time!</h1>
        {!quizCompleted && (
          <Question
            question={currentQuestion}
            onOptionClick={this.handleOptionClick}
          />
        )}
        {quizCompleted && (
          <div>
            <p>Quiz Completed! Final Score: {score}/{questions.length}</p>
          </div>
        )}
        {!quizCompleted && (
          <div>
            <button
              onClick={this.handlePreviousQuestion}
              disabled={currentQuestionIndex === 0}
            >
              Previous
            </button>
            <button onClick={this.handleNextQuestion}>Next Question</button>
          </div>
        )}
      </div>
    );
  }
}

export default QuizApp;
