import React, { useState } from "react";
import axios from "axios";
import "./Register.css";
import { storage } from "../config/firebase";
import { uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { ref as sRef } from "firebase/storage";
import { Link } from "react-router-dom";

const Register = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [dob, setDOB] = useState("");
  const [gender, setGender] = useState("male");
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const errors = {};

    if (!fullName) {
      alert("Name is required");
    }

    if (!email) {
      alert("Email Address is required");
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      alert("Email Address is Invalid");
    }

    if (!password) {
      alert("Password is required");
    } else if (password.length < 6) {
      alert("Password must be at least 6 characters");
    }

    if (password !== confirmPassword) {
      alert("Password does not matched");
    }

    if (!agreeTerms) {
      alert("You must agree to the Terms and Conditions");
    }

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleImageChange = (event) => {
    console.log("image");
    const file = event.target.files[0];
    setImageFile(file);
  };

  const handleSubmit = async (event) => {
    console.log("handle submit called");
    event.preventDefault();

    if (validateForm()) {
      const fileRef = sRef(storage, `user/${imageFile.name}`);
      const uploadTask = uploadBytesResumable(fileRef, imageFile);

      try {
        uploadTask.on("state_changed", async () => {
          try {
            const image = await getDownloadURL(fileRef);
            console.log(image + "download URL fetched");

            // After fetching the URL, proceed with form submission
            const response = await axios.post("http://localhost:4000/signup", {
              fullName,
              email,
              password,
              dob,
              gender,
              image,
              agreeTerms,
            });

            console.log(response.data);
            console.log("Form submitted");
            setFormSubmitted(true);
          } catch (error) {
            console.error("Error registering user:", error);
          }
        });
      } catch (error) {
        console.error("Error uploading file:", error);
      }
    }
  };

  const successMessage = formSubmitted ? (
    <div className="success-message">
      Form submitted successfully! Thank you for registering.
    </div>
  ) : null;

  return (
    <div className="registration-container">
      <h1>Student Registration</h1>
      {successMessage}

      {/* Personal Information */}
      <div className="form-group">
        <label htmlFor="fullName">Full Name:</label>
        <input
          type="text"
          id="fullName"
          name="fullName"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          required
        />
        {errors.fullName && <span className="error">{errors.fullName}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="email">Email Address:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        {errors.email && <span className="error">{errors.email}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          name="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {errors.password && <span className="error">{errors.password}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="confirmPassword">Confirm Password:</label>
        <input
          type="password"
          id="confirmPassword"
          name="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        {errors.confirmPassword && (
          <span className="error">{errors.confirmPassword}</span>
        )}
      </div>

      {/* Additional Information */}
      <div className="form-group">
        <label htmlFor="dob">Date of Birth:</label>
        <input
          type="date"
          id="dob"
          name="dob"
          value={dob}
          onChange={(e) => setDOB(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label htmlFor="gender">Gender:</label>
        <select
          id="gender"
          name="gender"
          value={gender}
          onChange={(e) => setGender(e.target.value)}
        >
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="Image">Upload Image:</label>
        <input
          type="file"
          id="image"
          name="image"
          onChange={handleImageChange}
        />
      </div>

      {/* Terms and Conditions */}
      <div className="form-group">
        <label htmlFor="agreeTerms">
          <input
            type="checkbox"
            id="agreeTerms"
            name="agreeTerms"
            checked={agreeTerms}
            onChange={(e) => setAgreeTerms(e.target.checked)}
            required
          />
          I have read and agree to the Terms and Conditions.
        </label>
        {errors.agreeTerms && (
          <span className="error">{errors.agreeTerms}</span>
        )}
      </div>

      {/* Submit Button */}
      <div className="form-group">
        <button type="submit" onClick={handleSubmit}>
          Register
        </button>
      </div>
      <div className="register-link mt-2 reg">
        Already Registered? <Link to="/login">Login</Link>
      </div>
    </div>
  );
};

export default Register;
