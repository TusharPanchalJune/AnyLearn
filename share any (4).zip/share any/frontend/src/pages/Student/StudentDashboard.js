// import React from "react";
// import { useState, useEffect } from "react";
// import axios from "axios";

// const StudentDashboard = () => {
//   const [sessionData, setSessionData] = useState(null);

//   const fetchSessionData = async () => {
//     try {
//       console.log("frintend");
//       const response = await axios.get("http://localhost:4000/getSession");
//       setSessionData(response.data);
//       console.log("method end");
//     } catch (error) {
//       console.error("Error fetching session data:", error);
//       throw error;
//     }
//   };

//   useEffect(() => {
//     fetchSessionData();
//   }, []);
//   return (
//     <div>
//       <h1>Student Dashboard</h1>
//       <h2>{sessionData.userid}</h2>
//     </div>
//   );
// };

// export default StudentDashboard;

import React, { useState, useEffect } from "react";
import axios from "axios";
import { fetchSessionData } from "./FetchData";

const StudentDashboard = () => {
  const [isLoading, setIsLoading] = useState(false); // Add a loading state
  ;const [sessionData, setSessionData] = useState(null);
  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
      setIsLoading(true);
      console.log("session ka ", sessionData);
    });
  }, [])

  // Conditionally render content based on isLoading and sessionData
  return (
    <div>
      {!isLoading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <h1>Student Dashboard</h1>
          <h2>{sessionData?.fullName}</h2>
        </div>
      )}
    </div>
  );
};

export default StudentDashboard;
