import axios from 'axios';

export const fetchSessionData = async (callback) => {
  try {
    const response = await axios.get("http://localhost:4000/getSession", {
      withCredentials: true,
    });
    callback(response.data); // Call the callback with the fetched data
  } catch (error) {
    console.error("Error fetching session data:", error);
    throw error;
  }
};
    