import React, { useState, useEffect } from "react";
import { storage, db } from "./config/firebase.js";
import { uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { ref as sRef } from "firebase/storage";
import axios from "axios";
import { fetchSessionData } from "./Student/FetchData.js";
import { useLocation, useNavigate } from "react-router-dom";

const containerStyle = {
  backgroundColor: "#f0f0f0",
  padding: "20px",
  borderRadius: "10px",
  boxShadow: "0 0 10px rgba(0, 0, 0, 0.2)",
  textAlign: "center",
  marginTop: "20px",
};

const inputStyle = {
  border: "1px solid #ccc",
  borderRadius: "5px",
  padding: "5px",
  margin: "5px",
};

const buttonStyle = {
  backgroundColor: "#007bff",
  color: "white",
  border: "none",
  padding: "10px 20px",
  borderRadius: "5px",
  cursor: "pointer",
  margin: "5px",
};

function UploadVideo() {
  const [downloadURL, setDownloadURL] = useState("");
  const [videoFile, setVideoFile] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [isVideoUploading, setIsVideoUploading] = useState(false);
  const [sessionData, setSessionData] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0); // Track upload progress
  const [uploadStatus, setUploadStatus] = useState(""); // Track upload status
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const courseId = queryParams.get("courseId");

  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);
      console.log(data);
      console.log("session set");
    });
  }, []);

  function handleVideoChange(event) {
    setVideoFile(event.target.files[0]);
  }

  function handleThumbnailChange(event) {
    setImageFile(event.target.files[0]);
  }

  function handleTitleChange(event) {
    setTitle(event.target.value);
  }

  function handleSubjectChange(event) {
    setSubject(event.target.value);
  }

  const handleVideoUpload = async () => {
    if (!videoFile) {
      alert("Please select a video first");
      return;
    }

    setIsVideoUploading(true);

    try {
      const fileRef = sRef(storage, `videos/${videoFile.name}`);
      const uploadTask = uploadBytesResumable(fileRef, videoFile);

      uploadTask.on(
        "state_changed",
        (snapshot) => {
          let progress =
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Upload progress: ${progress}%`);
          setUploadProgress(progress); // Update upload progress
        },
        (error) => {
          console.error("Error uploading file:", error);
          setUploadStatus("Upload failed"); // Update upload status
        },
        async () => {
          console.log("Upload completed");

          try {
            const url = await getDownloadURL(fileRef);
            setDownloadURL(url);
            setIsVideoUploading(false);
            console.log(url + "  url");
            setUploadStatus("Upload completed"); // Update upload status
          } catch (error) {
            console.error("Error:", error);
            setIsVideoUploading(false);
            setUploadStatus("Upload failed"); // Update upload status
          }
        }
      );
    } catch (error) {
      console.error("Error uploading video:", error);
      setIsVideoUploading(false);
      setUploadStatus("Upload failed"); // Update upload status
    }
  };

  const handleUpload = async (viddownloadURL) => {
    if (!title || !subject || !viddownloadURL || !imageFile) {
      console.error("Please fill in all fields and upload the video");
      return;
    }

    try {
      const imgfileRef = sRef(storage, `thumbnails/${imageFile.name}`);
      const imguploadTask = uploadBytesResumable(imgfileRef, imageFile);

      imguploadTask.on(
        "state_changed",
        (snapshot) => {
          let progress =
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Thumbnail Upload progress: ${progress}%`);
          setUploadProgress(progress); // Update upload progress
        },
        (error) => {
          console.error("Error uploading thumbnail:", error);
          setUploadStatus("Upload failed"); // Update upload status
        },
        async () => {
          console.log("Thumbnail Upload completed");

          try {
            const imgurl = await getDownloadURL(imgfileRef);
            console.log(imgurl + "  thumbnail url");

            try {
              console.log("now trying to put data");
              const response = await axios.post(
                "http://localhost:4000/teacherscourses",
                {
                  title,
                  subject,
                  downloadURL,
                  imgurl,
                  courseId,
                  teacherId: sessionData._id,
                }
              );
              alert(response);
              console.log("Video data saved:", response.data);
            } catch (error) {
              console.error("Error saving video data:", error);
            }
          } catch (error) {
            console.error("Error getting thumbnail URL:", error);
            setUploadStatus("Upload failed"); // Update upload status
          }
        }
      );
    } catch (error) {
      console.error("Error uploading thumbnail:", error);
      setUploadStatus("Upload failed"); // Update upload status
    }
  };

  return (
    <div style={containerStyle}>
      <h1>Tutor Page - Video Upload</h1>

      <input
        type="file"
        onChange={handleVideoChange}
        name="videoFile"
        id="videoFile"
        style={inputStyle}
      />
      <button
        onClick={handleVideoUpload}
        type="submit"
        style={buttonStyle}
        id="uploadButton"
        disabled={isVideoUploading}
      >
        Upload Video
      </button>

      {isVideoUploading && (
        <div>
          <p>Uploading Video... ({Math.floor(uploadProgress)}%)</p>
          <progress max="100" value={uploadProgress}></progress>
        </div>
      )}

      <h4>Thumbnail</h4>
      <input
        type="file"
        onChange={handleThumbnailChange}
        name="thumbnail"
        id="thumbnail"
        disabled={isVideoUploading}
        style={inputStyle}
      />
      <input
        placeholder="subject"
        type="text"
        onChange={handleSubjectChange}
        name="subject"
        id="subject"
        disabled={isVideoUploading}
        style={inputStyle}
      />
      <input
        placeholder="title"
        type="text"
        onChange={handleTitleChange}
        name="title"
        id="title"
        disabled={isVideoUploading}
        style={inputStyle}
      />

      <button
        onClick={() => handleUpload(downloadURL)}
        type="submit"
        style={buttonStyle}
        id="uploadButton"
        disabled={isVideoUploading}
      >
        Upload Thumbnail and Data
      </button>
      {uploadStatus && <p>{uploadStatus}</p>}
    </div>
  );
}

export default UploadVideo;
