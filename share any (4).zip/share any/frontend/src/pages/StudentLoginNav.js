import React from "react";
import "./style.css";
import { Link } from "react-router-dom";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";

const StudentLoginNav = ({ setUserData }) => {
  function handleLogout() {
   setUserData(null);
  }
  return (
    <nav className="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
      <Link
        to="/"
        className="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5"
      >
        <h2 class="m-0 text-primary">
          <i class="fa fa-book me-3"></i>AnyLearn
        </h2>
      </Link>
      <button
        type="button"
        className="navbar-toggler me-4"
        data-bs-toggle="collapse"
        data-bs-target="#navbarCollapse"
      >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarCollapse">
        <div className="navbar-nav ms-auto p-4 p-lg-0">
          <Link to="/" className="nav-item nav-link">
            Home
          </Link>
          <Link to="/about" className="nav-item nav-link">
            About
          </Link>
          <Link to="/purchased" className="nav-item nav-link">
            Courses
          </Link>

        
          <Link to="/contact" className="nav-item nav-link">
            Contact
          </Link>
        </div>

        <Link
          onClick={handleLogout}
          to="/login"
          className="btn btn-primary rounded-0 py-4 px-lg-5 d-none d-lg-block"
        >
          Log out<i className="fa fa-arrow-right ms-3"></i>
        </Link>
      </div>
    </nav>
  );
};
export default StudentLoginNav;
