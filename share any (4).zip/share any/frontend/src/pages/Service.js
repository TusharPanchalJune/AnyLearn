import React from 'react';

const Service = () => {
  const services = [
    {
      iconClass: 'fa-graduation-cap',
      title: 'Skilled Instructors',
      description: "Skilled Instructors Our experienced instructors are dedicated to providing you with the knowledge and expertise you need to succeed in your chosen field. They are here to guide you every step of the way.",delay: '0.1s',
    },
    {
      iconClass: 'fa-globe',
      title: 'Online Classes',
      description: 'Online Classes Experience engaging online classes that offer a dynamic and interactive learning environment. Join us to explore new horizons and expand your knowledge from the comfort of your home.',
      delay: '0.3s',
    },
    {
      iconClass: 'fa-home',
      title: 'Home Projects',
      description: 'Home Projects Embark on exciting home projects that allow you to unleash your creativity and enhance your living space. Transform your house into a personalized haven with our inspiring ideas and guidance.',
      delay: '0.5s',
    },
    {
      iconClass: 'fa-book-open',
      title: 'Book Library',
      description: 'Explore a vast collection of educational books and resources to enhance your learning experience.Our library is filled with textbooks, reference materials, and more to support your academic journey.',
      delay: '0.7s',
    },
  ];

  return (
    <div className="container-xxl py-5">
      <div className="container">
        <div className="row g-4">
          {services.map((service, index) => (
            <div key={index} className={`col-lg-3 col-sm-6 wow fadeInUp`} data-wow-delay={service.delay}>
              <div className="service-item text-center pt-3">
                <div className="p-4">
                  <i className={`fa fa-3x ${service.iconClass} text-primary mb-4`}></i>
                  <h5 className="mb-3">{service.title}</h5>
                  <p>{service.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Service;
