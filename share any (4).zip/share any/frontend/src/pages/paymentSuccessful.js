import React from "react";
import { useSearchParams } from "react-router-dom";

const PaymentSuccess = () => {
  const searchQuery = useSearchParams()[0];
  const refNum = searchQuery.get("reference");
  const course = searchQuery.get("coursename");
  return (
    <div className="d-flex justify-content-center my-5">
      <div>
        <h1>Order Successful</h1>
        <h3>Reference No.{refNum}</h3>
        <h3>Course: {course}</h3>
      </div>
    </div>
  );
};

export default PaymentSuccess;
