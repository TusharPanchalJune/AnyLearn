import React, { useState, useEffect } from "react";
import QuizResult from "./QuizResult";
import { fetchSessionData } from "./Student/FetchData";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [clickedOption, setClickedOption] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [quizData, setQuizData] = useState([]);
  const [user, setUser] = useState(null);
  const [sessionData, setSessionData] = useState(null);
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const courseId = queryParams.get("courseId");
  const quizn = queryParams.get("quizn");
  console.log(courseId);
  console.log(quizn);
  useEffect(() => {
    fetchSessionData((data) => {
      setSessionData(data);

      console.log("session ka ", sessionData);
    });
    fetchQuizDataFromBackend();
  }, []);

  const fetchQuizDataFromBackend = async () => {
    alert("caled");
    try {
      const response = await axios.post(
        "http://localhost:4000/getquestions",
        {
          courseId,
          quizn,
        },
        {
          withCredentials: true,
        }
      );
      const data = response.data;
      setQuizData(data);
    } catch (error) {
      console.error("Error fetching quiz data:", error);
    }
  };

  const changeQuestion = () => {
    updateScore();
    if (currentQuestion < quizData.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setClickedOption(0);
    } else {
      setShowResult(true);
      handleQuizCompletion();
    }
  };

  const updateScore = () => {
    if (clickedOption === quizData[currentQuestion].answer) {
      setScore(score + 1);
    }
  };

  const updateScoreInBackend = async (userId, newScore) => {
    console.log("backend method called");
    try {
      await fetch(`http://localhost:4000/updateUserScore`, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ score: newScore , userId }),
        withCredentials: true,
      });
      console.log("updated from fe");
    } catch (error) {
      console.error("Error updating user score:", error);
    }
  };

  const handleQuizCompletion = () => {
    updateScoreInBackend(sessionData._id, score);
    setShowResult(true);
  };

  const resetAll = () => {
    setShowResult(false);
    setCurrentQuestion(0);
    setClickedOption(0);
    setScore(0);
  };

  return (
    <div>
      <p className="heading-txt">Quiz APP</p>
      <div className="container">
        {quizData.length > 0 ? (
          showResult ? (
            <QuizResult
              score={score}
              totalScore={quizData.length}
              tryAgain={resetAll}
            />
          ) : (
            <>
              <div className="question">
                <span id="question-number">{currentQuestion + 1}. </span>
                <span id="question-txt">
                  {quizData[currentQuestion].question}
                </span>
              </div>
              <div className="option-container">
                {quizData[currentQuestion].options.map((option, i) => {
                  return (
                    <button
                      className={`option-btn ${
                        clickedOption === i  ? "checked" : null
                      }`}
                      key={i}
                      onClick={() => setClickedOption(i )}
                    >
                      {option}
                    </button>
                  );
                })}
              </div>
              <input
                type="button"
                value="Next"
                id="next-button"
                onClick={changeQuestion}
              />
            </>
          )
        ) : (
          <p>Loading quiz data...</p>
        )}
      </div>
    </div>
  );
}

export default Quiz;
