import React, { useState, useEffect } from "react";
import "./style.css";
import axios from "axios";
import { useLocation, Link } from "react-router-dom";
import CourseDets from "./CoursDets";

const Video = ({ setUrl }) => {
  const [videos, setVideos] = useState([]);
  const [course, setCourse] = useState(null); // Store the course details here
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const courseId = queryParams.get("courseId");

  const handelChanges = (videourl) => {
    console.log(videourl + "this is the ");
    setUrl(videourl);
  };

  useEffect(() => {
    fetchCourse(); // Fetch course details
    fetchVideos();
  }, []);

  const fetchCourse = async () => {
    try {
      // Fetch the entire course object from the backend
      const response = await axios.post("http://localhost:4000/uservideos", {
        courseId,
      });

      setCourse(response.data); // Set the course details from the API response
    } catch (error) {
      console.error("Error fetching course:", error);
    }
  };

  const fetchVideos = async () => {
    try {
      const response = await axios.post("http://localhost:4000/uservideos", {
        courseId,
      });

      // Check if the 'videos' property exists in the response data
      if (response.data.videos) {
        setVideos(response.data.videos); // Set the videos array from the API response
      }
    } catch (error) {
      console.error("Error fetching videos:", error);
    }
  };

  return (
    <section className="playlist-videos">
      {/* Pass the course object to the CourseDets component */}
      {course && <CourseDets course={course} />}
      <h1 className="heading">Playlist </h1>
      <div className="box-container">
        {videos.map((video) => (
          <Link
            className="box"
            to="/watchvideo"
            key={video.id}
            onClick={() => handelChanges(video.downloadURL)}
          >
            <i className="fas fa-play"></i>
            <img src={video.imgurl} alt={video.title} />
            <h3>{video.title}</h3>
            <h3>{video.subject}</h3>
          </Link>
        ))}
      </div>
      <div className="justify-content-center">
        <Link
          to={`/quizapp?&courseId=${courseId}&quizn=1`}
          className="inline-btn mx-2"
        >
          Quiz 1
        </Link>
        <Link
          to={`/quizapp?&courseId=${courseId}&quizn=2`}
          className="inline-btn"
        >
          Quiz 2
        </Link>
      </div>
    </section>
  );
};

export default Video;
